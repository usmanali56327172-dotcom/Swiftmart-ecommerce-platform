# Deployment Guide

Two supported deployment paths — pick one:
- **Option A/B (below):** split architecture — **Frontend (Next.js)** → Vercel,
  **Backend (Express API) + PostgreSQL** → Railway or Render. Simplest if you just want it live
  fast and don't mind two providers.
- **Option C:** everything on **one VPS** you control (DigitalOcean, Hetzner, Linode, AWS
  Lightsail, etc.) via Docker Compose + Nginx + Let's Encrypt, using the included `deploy.sh`.
  Better fit if you want local-disk image uploads to persist reliably, full control over the
  server, or a single predictable monthly bill. **This is the path most people mean by "deploy
  on my own server" — jump to Option C if that's you.**

---

## 1. Database — Railway (or any managed Postgres)

1. Create a new project on [railway.app](https://railway.app) → **New → Database → PostgreSQL**.
2. Copy the generated `DATABASE_URL` (found under the Postgres service's **Connect** tab).
3. You'll paste this into the API service's environment variables in step 2.

*(Alternatives: Supabase, Neon, or Render's managed Postgres — any standard `postgresql://` URL works.)*

---

## 2. Backend API — Railway

1. Push this repo to GitHub.
2. In Railway: **New → Deploy from GitHub repo**, select the repo, and set the **root
   directory** to `server`.
3. Railway auto-detects the `Dockerfile` in `server/` — no build config needed.
4. Add environment variables (Service → **Variables**):
   ```
   NODE_ENV=production
   PORT=5000
   CLIENT_URL=https://your-frontend-domain.vercel.app
   DATABASE_URL=<from step 1>
   JWT_ACCESS_SECRET=<openssl rand -hex 32>
   JWT_REFRESH_SECRET=<openssl rand -hex 32>
   JWT_ACCESS_EXPIRES_IN=15m
   JWT_REFRESH_EXPIRES_IN=30d
   STRIPE_SECRET_KEY=sk_live_...           # or sk_test_... while validating
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```
5. Add a **deploy-time command** (Settings → Deploy) to run migrations before start:
   ```
   npx prisma migrate deploy && node dist/server.js
   ```
   (the provided `Dockerfile` already builds `dist/`, so this just needs to run at container start).
6. Once deployed, note the public URL, e.g. `https://swiftmart-api.up.railway.app`.
7. Seed production data once (via Railway's shell or a one-off run):
   ```
   railway run npm run seed
   ```
   *(Skip this in a real production launch — seed data is for demos only.)*

### Alternative: Render
- **New → Web Service**, connect the repo, root directory `server`, environment: Docker.
- Add the same environment variables under **Environment**.
- Add a **Render PostgreSQL** instance and copy its internal connection string into `DATABASE_URL`.
- Render's "Pre-Deploy Command" field is the right place for `npx prisma migrate deploy`.

---

## 3. Frontend — Vercel

1. In [vercel.com](https://vercel.com): **New Project → Import Git Repository**, select this repo.
2. Set **Root Directory** to `client`.
3. Framework preset: Next.js (auto-detected).
4. Add environment variables (Project → Settings → Environment Variables):
   ```
   NEXT_PUBLIC_API_URL=https://swiftmart-api.up.railway.app/api/v1
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
   ```
5. Deploy. Vercel gives you a `https://<project>.vercel.app` domain (attach a custom domain
   under Settings → Domains if desired).
6. Go back to the backend's `CLIENT_URL` env var and update it to this final Vercel URL, then
   redeploy the backend so CORS allows it.

---

## 4. Stripe Webhook (production)

1. In the [Stripe Dashboard](https://dashboard.stripe.com/webhooks) → **Add endpoint**.
2. Endpoint URL: `https://swiftmart-api.up.railway.app/api/v1/payments/webhook`
3. Events to send: `payment_intent.succeeded`, `payment_intent.payment_failed`.
4. Copy the **Signing secret** into the backend's `STRIPE_WEBHOOK_SECRET` env var and redeploy.

---

## 5. Post-Deploy Checklist

- [ ] Visit `https://<api-domain>/health` → should return `{ "status": "ok" }`
- [ ] Visit `https://<api-domain>/api-docs` → Swagger UI loads
- [ ] Register a test account on the live frontend and confirm login persists across refresh
- [ ] Add a product to cart → checkout with a Stripe test card (`4242 4242 4242 4242`) → confirm
      the order appears with status `PAID` after the webhook fires
- [ ] Log in as an admin (promote a user's `role` to `ADMIN` directly in the database, or seed one)
      and confirm the dashboard, product CRUD, and order status updates all work
- [ ] Rotate any secrets that were used during local testing before going live

---

## 6. Scaling Notes

- The API is stateless (JWT-based), so it horizontally scales behind a load balancer with no
  sticky-session requirements — the only shared state is Postgres.
- Add a CDN (Vercel's is automatic) in front of the frontend; product images should be moved
  from hosted placeholder URLs to a proper object store (S3/Cloudinary) with a CDN in front for
  a real production launch.
- For catalog search at scale, swap `ProductService.list`'s `ILIKE` filters for Postgres full-text
  search (`tsvector`/`tsquery`) or an external search engine (Meilisearch/Algolia/Elasticsearch).
- Add Redis for session/rate-limit storage if you scale the API beyond a single instance
  (the in-memory rate limiter is per-instance).

---

## Option C — Single VPS with Docker Compose + Nginx + Let's Encrypt

Everything (Postgres, API, frontend, reverse proxy, SSL) runs on one server you control. This is
what `docker-compose.prod.yml`, `deploy.sh`, and the `nginx/` folder in this repo are for.

### Prerequisites

- A VPS running Ubuntu 22.04+ (or similar) with at least 2GB RAM — DigitalOcean, Hetzner, Linode,
  AWS Lightsail, etc. all work fine.
- A domain name, with an **A record** pointing at the server's public IP (and ideally a second A
  record for `www.<yourdomain>` pointing the same place). DNS must be live before you request a
  certificate — Let's Encrypt verifies domain ownership over HTTP.
- Ports **80** and **443** open on the server's firewall (`ufw allow 80,443/tcp` on Ubuntu).
- Docker + Docker Compose installed:
  ```bash
  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker $USER   # log out and back in after this
  ```

### Steps

**1. Get the code onto the server**
```bash
git clone <your-repo-url> swiftmart && cd swiftmart
```

**2. Configure environment variables**
```bash
cp .env.example .env
nano .env
```
Fill in at minimum: `DOMAIN`, `LETSENCRYPT_EMAIL`, `POSTGRES_PASSWORD`, `JWT_ACCESS_SECRET` and
`JWT_REFRESH_SECRET` (generate each with `openssl rand -hex 32`), and whichever payment
credentials you're using (Stripe/JazzCash/bank details) — see `server/.env.example` for what each
one does.

**3. Run the deploy script**
```bash
chmod +x deploy.sh
./deploy.sh
```
This builds and starts Postgres, the API, and the frontend; brings Nginx up over plain HTTP long
enough for Let's Encrypt to verify domain ownership; requests the certificate; then switches
Nginx to the HTTPS config and starts the auto-renewal container. Takes 2–5 minutes on a fresh
server (mostly Docker image builds).

**4. Verify**
- `https://yourdomain.com` — storefront loads over HTTPS with a valid padlock
- `https://yourdomain.com/health` — returns `{"status":"ok"}`
- `https://yourdomain.com/api-docs` — Swagger UI loads
- Register an account, add something to cart, and place a test order

**5. Seed demo data (optional, first deploy only)**
```bash
docker compose -f docker-compose.prod.yml exec server npm run seed
```
Skip this for a real launch — it creates demo accounts and sample products.

### Redeploying after code changes

```bash
git pull
./deploy.sh
```
Re-running `deploy.sh` is safe — it detects the existing certificate and skips straight to
rebuilding and restarting the app containers; it won't re-request a certificate or touch Nginx's
SSL config unless the certificate is missing.

### What's persisted across restarts/redeploys

- **Database** — `postgres_data` Docker volume
- **Uploaded product photos** — `server_uploads` Docker volume (mounted at `/app/uploads` in the
  API container, matching `middleware/upload.ts`)
- **TLS certificates** — `./certbot/conf` on the host, auto-renewed by the `certbot` service every
  12 hours (renews only when within 30 days of expiry — certbot's own default)

### Keeping Nginx serving the renewed certificate

Certbot renewing the certificate file does **not** make the already-running Nginx process pick it
up on its own — Nginx needs a reload to re-read `/etc/letsencrypt/live/<domain>/fullchain.pem`
after it changes. The simplest reliable fix is a monthly host-level cron job that restarts the
Nginx container (well within the 90-day certificate lifetime, so there's no window where an
expired cert is served):
```bash
# crontab -e (as a user in the `docker` group, or use /etc/cron.d with an explicit user)
0 3 1 * * cd /path/to/swiftmart && docker compose -f docker-compose.prod.yml restart nginx
```
Re-running `./deploy.sh` (e.g. on every redeploy) also force-recreates the `nginx` container, so
if you deploy at least monthly you don't need the cron job at all.

### Common issues

| Symptom | Likely cause |
|---|---|
| Certbot fails with a timeout or "connection refused" | DNS hasn't propagated yet, or port 80 isn't open — `dig +short yourdomain.com` should return this server's IP before retrying |
| `nginx` container restarts in a loop | `nginx/conf.d/app.conf` wasn't generated — check `deploy.sh` output for the `envsubst` step, or that `DOMAIN` is set in `.env` |
| Site loads over HTTP but not HTTPS | The bootstrap step didn't complete — re-run `./deploy.sh`, or check `docker compose -f docker-compose.prod.yml logs nginx` |
| 502 from Nginx | The `server` or `client` container isn't healthy yet — `docker compose -f docker-compose.prod.yml ps` and check logs for whichever is down |
| Stripe/JazzCash webhooks failing | Make sure `CLIENT_URL`, `JAZZCASH_RETURN_URL`, and the Stripe webhook endpoint in your Stripe dashboard all use the final `https://yourdomain.com` — not `localhost` |

### Updating the JazzCash/Stripe webhook URLs for this domain

- Stripe dashboard → Webhooks → endpoint URL: `https://yourdomain.com/api/v1/payments/webhook`
- JazzCash's callback is already wired to `https://yourdomain.com/api/v1/payments/jazzcash/callback`
  via the `JAZZCASH_RETURN_URL`/`DOMAIN` env vars — no dashboard step needed on their side beyond
  your merchant onboarding.

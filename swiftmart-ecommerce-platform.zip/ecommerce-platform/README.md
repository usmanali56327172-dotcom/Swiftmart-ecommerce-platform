# SwiftMart — Enterprise E-Commerce Platform

A full-stack, production-grade e-commerce platform inspired by Amazon-style shopping
experiences: catalog browsing with search/filters, cart & checkout with **card (Stripe),
JazzCash, bank transfer, and Cash on Delivery**, wishlists, product comparison, reviews &
ratings, coupons, real-time order tracking, and a full admin dashboard with inventory and
sales analytics.

> **Demo credentials** (after seeding): <br>
> Admin — `admin@swiftmart.com` / `Password1` <br>
> Customer — `customer@swiftmart.com` / `Password1`

---

## 1. Tech Stack & Why

| Layer | Choice | Why |
|---|---|---|
| Frontend | **Next.js 14 (App Router) + TypeScript** | SSR/SSG for SEO-critical product pages, file-based routing, great DX |
| Styling | **Tailwind CSS** + hand-rolled component library (CVA) | Fast, consistent, themeable (dark mode built in) |
| Client state | **Zustand** (auth/UI) + **React Query** (server state) | Avoids prop-drilling; React Query handles caching/refetching/optimistic UI |
| Backend | **Node.js + Express + TypeScript** | Battle-tested, huge ecosystem, easy to reason about for interviewers |
| Database | **PostgreSQL + Prisma ORM** | Relational integrity for orders/inventory; Prisma gives type-safe queries & migrations |
| Auth | **JWT (access + refresh) with rotation**, bcrypt password hashing | Stateless access tokens (15 min) + httpOnly-cookie refresh tokens (30 days) with rotation & revocation |
| Payments | **Stripe** (PaymentIntents + webhooks) | Industry standard; webhook is the source of truth for payment confirmation |
| Validation | **Zod** (both frontend & backend) | Single source of truth for request shapes, easy composition |
| Docs | **OpenAPI 3 + Swagger UI** | Live, interactive API docs at `/api-docs` |
| Infra | **Docker + docker-compose** | One-command local environment; deploy-ready containers |

---

## 2. Monorepo Structure

```
ecommerce-platform/
├── server/                     # Express + TypeScript API
│   ├── prisma/
│   │   ├── schema.prisma       # Full relational data model
│   │   └── seed.ts             # Demo data: users, categories, brands, products, coupons
│   ├── docs/
│   │   └── openapi.yaml        # API specification (served at /api-docs)
│   ├── src/
│   │   ├── config/             # env, prisma client, logger, swagger
│   │   ├── middleware/         # auth, validation, rate limiting, error handling
│   │   ├── validators/         # Zod request schemas
│   │   ├── services/           # business logic (one class per domain)
│   │   ├── controllers/        # thin HTTP layer calling services
│   │   ├── routes/             # route wiring + middleware composition
│   │   ├── utils/              # ApiError, ApiResponse, jwt, password, etc.
│   │   ├── app.ts              # Express app assembly
│   │   └── server.ts           # entrypoint + graceful shutdown
│   └── Dockerfile
├── client/                     # Next.js 14 App Router frontend
│   └── src/
│       ├── app/                 # routes (pages), grouped by feature
│       ├── components/
│       │   ├── ui/              # Button, Rating, Badge, Skeleton, ThemeToggle
│       │   ├── layout/          # Navbar, Footer
│       │   ├── product/         # ProductCard, ProductFilters, grid skeleton
│       │   └── checkout/        # Stripe PaymentForm
│       ├── hooks/                # React Query hooks per domain
│       ├── store/                # Zustand stores (auth, cart UI, compare UI)
│       └── lib/                  # axios instance w/ token refresh, utils
├── docker-compose.yml
└── DEPLOYMENT.md
```

**Design principles applied throughout:**
- **Service layer separation** — controllers never touch Prisma directly; all business rules
  (stock checks, coupon math, rating recalculation) live in `services/`, so they're unit-testable
  and reusable.
- **Server-computed money math** — cart/order totals (discount, tax, shipping) are always
  calculated server-side (`CartService.calculateTotals`) — the client only *displays* numbers,
  never sends them.
- **Transactional checkout** — placing an order (`OrderService.createFromCart`) validates stock,
  snapshots prices, decrements inventory, and clears the cart in a single Prisma `$transaction`,
  so a partial failure can't leave inconsistent state.
- **Soft deletes for products** — deleting a product sets `isActive: false` instead of a hard
  delete, preserving referential integrity for historical orders/reviews.
- **Webhook-driven payment confirmation** — the client's "success" screen is UX only; the
  Stripe webhook (`payment_intent.succeeded`) is the only thing that actually marks an order
  as paid, which is the correct pattern for production payment systems.

---

## 3. Feature Checklist

| Feature | Status |
|---|---|
| JWT auth (register/login/refresh/logout), role-based access | ✅ |
| Product catalog: search, category/brand/price/rating filters, sort, pagination | ✅ |
| Categories & brands (nested categories supported) | ✅ |
| Product detail page with gallery, related products | ✅ |
| Wishlist | ✅ |
| Compare products (up to 4, attribute diffing) | ✅ |
| Cart (server-persisted, real-time totals) | ✅ |
| Coupons (percentage/fixed, min order, usage limits, expiry) | ✅ |
| Checkout (address book + 4 payment methods: card, JazzCash, bank transfer, COD) | ✅ |
| Order tracking (status timeline + event log) | ✅ |
| Reviews & ratings (one per user, verified-purchase badge, rating aggregation) | ✅ |
| Customer dashboard (orders, wishlist, compare, profile) | ✅ |
| Admin dashboard (KPIs, revenue chart, orders-by-status, top products, low-stock alerts) | ✅ |
| Admin product CRUD + inventory logging | ✅ |
| Product image upload (drag-and-drop, Multer + local disk storage) | ✅ |
| Admin order management (status updates → tracking events) | ✅ |
| Admin coupon management | ✅ |
| Dark mode | ✅ |
| Responsive design (mobile/tablet/desktop) | ✅ |
| API documentation (OpenAPI/Swagger) | ✅ |
| Rate limiting, Helmet, CORS, centralized error handling | ✅ |

**Scaffolded / natural next steps** (see `EXTENDING.md`-style notes inline below) — these are
intentionally left as extension points rather than filled with placeholder code, since a real
hiring project benefits more from depth on the core flows than breadth on every edge case:
- Cloud object storage for uploads (currently local disk under `server/uploads`, served statically —
  swap `services/upload` for an S3/Cloudinary SDK call to survive redeploys/scale past one instance)
- Email notifications (order confirmation, shipping updates) — add a `services/email.service.ts` using Resend/SendGrid
- Full-text search relevance (currently `ILIKE`-based; swap in Postgres `tsvector` or Algolia/Meilisearch for scale)
- Multi-vendor / marketplace support
- Automated test suite (Vitest is wired into `package.json` — add tests under `server/src/**/*.test.ts`)

---

## 4. Local Development Setup

### Prerequisites
- Node.js 20+
- PostgreSQL 16 (or use the provided Docker setup)
- A free [Stripe](https://dashboard.stripe.com/register) test account (for payments)

### Option A — Docker Compose (fastest)
```bash
git clone <your-repo-url> swiftmart && cd swiftmart
cp server/.env.example server/.env      # then fill in JWT secrets + Stripe keys
docker compose up --build
```
This starts Postgres, runs migrations, and starts both the API (port 5000) and the Next.js
app (port 3000). Seed the database once containers are healthy:
```bash
docker compose exec server npm run seed
```

### Option B — Run natively

**1. Backend**
```bash
cd server
cp .env.example .env        # fill in DATABASE_URL, JWT secrets, Stripe keys
npm install
npm run prisma:migrate      # creates tables
npm run seed                # demo data
npm run dev                 # http://localhost:5000
```
API docs: `http://localhost:5000/api-docs`
Health check: `http://localhost:5000/health`

**2. Frontend**
```bash
cd client
cp .env.local.example .env.local   # point at your API + Stripe publishable key
npm install
npm run dev                        # http://localhost:3000
```

### Stripe test cards
Use `4242 4242 4242 4242`, any future expiry, any CVC, any postal code, to simulate a
successful payment in test mode. To receive webhook events locally, use the Stripe CLI:
```bash
stripe listen --forward-to localhost:5000/api/v1/payments/webhook
```
Copy the printed webhook signing secret into `server/.env` as `STRIPE_WEBHOOK_SECRET`.

---

## 5. Environment Variables

**server/.env**
```
NODE_ENV=development
PORT=5000
CLIENT_URL=http://localhost:3000
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/ecommerce?schema=public
JWT_ACCESS_SECRET=<generate with: openssl rand -hex 32>
JWT_REFRESH_SECRET=<generate with: openssl rand -hex 32>
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=30d
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
JAZZCASH_MERCHANT_ID=MC00000
JAZZCASH_PASSWORD=sandbox_password
JAZZCASH_INTEGRITY_SALT=sandbox_salt
JAZZCASH_API_BASE=https://sandbox.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction
JAZZCASH_RETURN_URL=http://localhost:3000/checkout
BANK_NAME=Meezan Bank
BANK_ACCOUNT_TITLE=SwiftMart Retail (Pvt) Ltd
BANK_ACCOUNT_NUMBER=PK00 MEZN 0000 0123 4567 8901
BANK_IBAN=PK00MEZN0000012345678901
```

**client/.env.local**
```
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

---

## 6a. Product Photography — URL or Direct Upload

The admin **Products** form (`/admin/products`) supports two ways to set a product's images:

1. **Upload from your device** — click "Upload" next to the thumbnail, or "Upload Images" for
   the gallery. Files go to `POST /api/v1/uploads/images`, are validated (JPEG/PNG/WebP/GIF/AVIF,
   5MB max per file) by `server/src/utils/multer.ts`, saved to `server/uploads/products/`, and
   served back as a public URL via `express.static` (see `app.ts`). The returned URL is inserted
   into the form automatically.
2. **Paste an existing URL** — any hosted image link (Unsplash, Cloudinary, your own CDN) works
   directly; `next.config.js` allows images from any HTTPS host for this reason.

> **Local disk storage is for development/demo only.** It works great on localhost or a single
> server, but won't survive a redeploy on most PaaS platforms (Railway/Render's filesystem isn't
> persistent) and can't be shared across multiple instances. For production, swap the storage
> engine in `utils/multer.ts` from `multer.diskStorage` to an S3-compatible adapter
> (`multer-s3`, or Cloudinary's SDK) — the rest of the app only ever deals with a plain image URL
> string, so nothing else needs to change. The `docker-compose.yml` setup already mounts a
> named volume (`server_uploads`) so uploads at least survive container restarts if you deploy
> that way.

## 6b. Payment Methods — How Each One Works

Checkout supports four methods (`server/src/validators/order.validator.ts` enforces the enum),
each with a different confirmation model:

| Method | Flow | Source of truth for "paid" |
|---|---|---|
| **Card (Stripe)** | `OrderService` creates a Stripe `PaymentIntent`; the frontend confirms it with Stripe.js (`components/checkout/PaymentForm.tsx`). | The **Stripe webhook** (`payment_intent.succeeded`) — never the client redirect alone. |
| **JazzCash** | `JazzCashService.buildTransactionRequest` builds and HMAC-SHA256-signs the MWALLET payload per JazzCash's spec (sorted `pp_*` fields + integrity salt), then the browser form-posts it to JazzCash. The customer approves on their phone. | JazzCash's **signed callback** to `/api/v1/payments/jazzcash/callback` — the signature is re-derived and compared with `crypto.timingSafeEqual` before any order is touched. |
| **Bank Transfer** | Order is created with `paymentStatus = AWAITING_VERIFICATION` and the customer is shown the store's bank details (`BankTransferService.getBankDetails`). They submit their transfer reference/slip number. | An **admin manually verifies** the transfer via `PATCH /orders/:id/bank-transfer/verify` (visible in the admin Orders table), which flips the order to `PAID`. |
| **Cash on Delivery** | Order is created with `status = PENDING`; no payment is collected upfront. | Marked paid/delivered by an admin when cash is collected on delivery. |

This mirrors how real Pakistani e-commerce checkouts are built: card payments go through a
gateway with webhook confirmation, JazzCash uses a signed mobile-wallet handshake, and bank
transfers are inherently a manual-reconciliation flow (no bank exposes a real-time confirmation
API to merchants without a formal integration) — the demo's admin "Verify Payment" button stands
in for that manual reconciliation step.

> **Going to production with JazzCash:** register as a JazzCash merchant to get real
> `pp_MerchantID` / `pp_Password` / `pp_IntegritySalt` values, and point `JAZZCASH_API_BASE` at
> their production endpoint instead of the sandbox one. The signing algorithm here matches their
> published spec, but test end-to-end against the sandbox before going live.

---

## 6b. Product Photography — URLs or Direct Upload

The admin **Products** form supports both ways to set a product's images:
- **Upload from your device** — click "Upload" next to the thumbnail, or "Upload Images" for the
  gallery. Files go to `POST /api/v1/uploads` (admin-only, `multer` disk storage under
  `server/uploads`, max 5MB/file, up to 6 files, JPEG/PNG/WEBP/GIF/AVIF only), which returns public
  URLs served statically at `/uploads/<filename>`.
- **Paste a URL** — any already-hosted image link (Unsplash, Cloudinary, your own CDN) works too;
  both approaches write into the same `thumbnail` / `images[]` fields, so you can mix and match.

Uploaded files are **not committed to git** (`server/uploads/*` is gitignored) and, in the Docker
setup, persist across restarts via the `server_uploads` volume in `docker-compose.yml`. If you
deploy the API to a platform without persistent disk (e.g. most serverless hosts), swap the
storage in `middleware/upload.ts` for an S3/Cloudinary SDK call — the controller only needs to
keep returning a list of public URLs, so nothing else in the app needs to change.

---

## 6. API Documentation

Interactive Swagger UI is served at **`/api-docs`** once the server is running, generated from
`server/docs/openapi.yaml`. It documents every endpoint's request/response shape, auth
requirements, and error codes — import that file directly into Postman or Insomnia if you
prefer a GUI client.

---

## 7. Security Notes

- Passwords hashed with **bcrypt** (12 salt rounds).
- Access tokens are short-lived (15 min) and kept **in memory only** on the client (never
  `localStorage`), minimizing XSS exposure. Refresh tokens are **httpOnly, sameSite=lax**
  cookies, scoped to `/api/v1/auth/refresh`, and rotated + revoked on every use.
- All mutating admin routes are protected by both `authenticate` (valid JWT) and
  `authorize("ADMIN")` (role check) middleware.
- `helmet`, CORS allow-listing, and `express-rate-limit` (tighter limits on auth routes) are
  applied globally.
- All Stripe amounts are computed server-side from the database — the client never dictates
  a price.
- Zod validates every request body/query/params before it reaches a controller.

---

## 8. Deployment

See [`DEPLOYMENT.md`](./DEPLOYMENT.md) for two paths: a split **Vercel + Railway/Render** setup,
or a single **VPS with Docker Compose + Nginx + Let's Encrypt** (own server, own domain) using
the included `docker-compose.prod.yml` and `deploy.sh` — run `./deploy.sh` after filling in
`.env` and it handles the build, SSL certificate issuance, and going live end to end.

---

## 9. License

MIT — free to use this project as a portfolio piece or a starting point for your own product.

/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // Product photography is admin-editable (uploaded files or pasted URLs),
    // so we allow any HTTPS host rather than whitelisting one CDN, plus
    // localhost over plain HTTP for uploads served by the API in local dev.
    remotePatterns: [
      { protocol: "https", hostname: "**" },
      { protocol: "http", hostname: "localhost" },
    ],
  },
  reactStrictMode: true,
};

module.exports = nextConfig;

"use client";

import { useParams } from "next/navigation";
import Image from "next/image";
import { CheckCircle2, Circle } from "lucide-react";
import { useOrder } from "@/hooks/useOrders";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

const TIMELINE_STEPS = ["PENDING", "PAID", "PROCESSING", "SHIPPED", "OUT_FOR_DELIVERY", "DELIVERED"];

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data: order, isLoading } = useOrder(id);

  if (isLoading || !order) return <div className="container py-16 text-center text-ink-500">Loading order...</div>;

  const currentStepIndex = TIMELINE_STEPS.indexOf(order.status);

  return (
    <div className="container py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Order {order.orderNumber}</h1>
          <p className="text-sm text-ink-500">Placed on {formatDate(order.createdAt)}</p>
        </div>
        <Badge variant={order.status === "DELIVERED" ? "success" : order.status === "CANCELLED" ? "danger" : "warning"}>
          {order.status.replace(/_/g, " ")}
        </Badge>
      </div>

      {/* Tracking timeline */}
      {!["CANCELLED", "REFUNDED"].includes(order.status) && (
        <div className="card mb-8 p-6">
          <h3 className="mb-5 font-semibold">Order Tracking</h3>
          <div className="flex items-center justify-between">
            {TIMELINE_STEPS.map((step, i) => (
              <div key={step} className="flex flex-1 flex-col items-center text-center">
                <div className="flex items-center w-full">
                  {i > 0 && <div className={`h-0.5 flex-1 ${i <= currentStepIndex ? "bg-brand-500" : "bg-ink-200 dark:bg-ink-700"}`} />}
                  {i <= currentStepIndex ? (
                    <CheckCircle2 className="text-brand-500 shrink-0" size={22} />
                  ) : (
                    <Circle className="text-ink-300 dark:text-ink-600 shrink-0" size={22} />
                  )}
                  {i < TIMELINE_STEPS.length - 1 && <div className={`h-0.5 flex-1 ${i < currentStepIndex ? "bg-brand-500" : "bg-ink-200 dark:bg-ink-700"}`} />}
                </div>
                <span className="mt-2 text-[11px] font-medium text-ink-500">{step.replace(/_/g, " ")}</span>
              </div>
            ))}
          </div>

          <div className="mt-6 space-y-3 border-t border-ink-100 pt-4 dark:border-ink-800">
            {order.trackingEvents.map((e: any) => (
              <div key={e.id} className="flex justify-between text-sm">
                <span>{e.message}{e.location ? ` — ${e.location}` : ""}</span>
                <span className="text-ink-400">{formatDate(e.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="space-y-3 lg:col-span-2">
          {order.items.map((item: any) => (
            <div key={item.id} className="card flex gap-4 p-4">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-800">
                <Image src={item.thumbnail} alt={item.title} fill className="object-cover" />
              </div>
              <div className="flex flex-1 items-center justify-between">
                <div>
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-ink-500">Qty: {item.quantity}</div>
                </div>
                <span className="font-bold">{formatCurrency(Number(item.price) * item.quantity)}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="card space-y-3 p-6">
          <h3 className="font-semibold">Payment</h3>
          <div className="flex items-center justify-between text-sm">
            <span className="text-ink-500">Method</span>
            <span className="font-medium">
              {{ CARD: "Card", JAZZCASH: "JazzCash", BANK_TRANSFER: "Bank Transfer", COD: "Cash on Delivery" }[order.paymentMethod as string] ?? order.paymentMethod}
            </span>
          </div>
          {order.paymentMethod === "BANK_TRANSFER" && (
            <div className="rounded-lg bg-ink-50 p-3 text-xs text-ink-600 dark:bg-ink-800 dark:text-ink-300">
              {order.paymentStatus === "SUCCEEDED"
                ? "Your bank transfer has been verified."
                : order.bankTransferReference
                ? `Reference "${order.bankTransferReference}" submitted — awaiting verification from our team.`
                : "We're waiting for your transfer reference. Check your confirmation email for the account details."}
            </div>
          )}
        </div>

        <div className="card space-y-3 p-6">
          <h3 className="font-semibold">Shipping Address</h3>
          <p className="text-sm text-ink-600 dark:text-ink-300">
            {order.address.fullName}<br />
            {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}<br />
            {order.address.city}, {order.address.state} {order.address.postalCode}<br />
            {order.address.country} · {order.address.phone}
          </p>
          <div className="space-y-2 border-t border-ink-100 pt-3 text-sm dark:border-ink-800">
            <div className="flex justify-between"><span className="text-ink-500">Subtotal</span><span>{formatCurrency(order.subtotal)}</span></div>
            {Number(order.discount) > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>-{formatCurrency(order.discount)}</span></div>}
            <div className="flex justify-between"><span className="text-ink-500">Shipping</span><span>{formatCurrency(order.shippingFee)}</span></div>
            <div className="flex justify-between"><span className="text-ink-500">Tax</span><span>{formatCurrency(order.tax)}</span></div>
            <div className="flex justify-between border-t border-ink-100 pt-2 font-bold dark:border-ink-800"><span>Total</span><span>{formatCurrency(order.total)}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

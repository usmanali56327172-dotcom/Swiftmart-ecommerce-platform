"use client";

import { useState } from "react";
import Link from "next/link";
import { useMyOrders } from "@/hooks/useOrders";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

const statusVariant = (s: string): "success" | "danger" | "warning" | "default" =>
  s === "DELIVERED" ? "success" : s === "CANCELLED" || s === "REFUNDED" ? "danger" : "warning";

export default function OrdersPage() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useMyOrders(page);

  return (
    <div className="container py-8">
      <h1 className="mb-6 text-2xl font-bold">My Orders</h1>
      {isLoading ? (
        <p className="text-ink-500">Loading orders...</p>
      ) : data?.data?.length ? (
        <div className="space-y-4">
          {data.data.map((o: any) => (
            <Link key={o.id} href={`/account/orders/${o.id}`} className="card flex flex-col gap-3 p-5 hover:border-brand-300 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="font-semibold">{o.orderNumber}</div>
                <div className="text-sm text-ink-500">Placed on {formatDate(o.createdAt)} · {o.items.length} item(s)</div>
              </div>
              <div className="flex items-center gap-4">
                <span className="font-bold">{formatCurrency(o.total)}</span>
                <Badge variant={statusVariant(o.status)}>{o.status.replace(/_/g, " ")}</Badge>
              </div>
            </Link>
          ))}
          {data.pagination.totalPages > 1 && (
            <div className="flex justify-center gap-2 pt-4">
              {Array.from({ length: data.pagination.totalPages }).map((_, i) => (
                <button key={i} onClick={() => setPage(i + 1)} className={`h-9 w-9 rounded-full text-sm ${page === i + 1 ? "bg-brand-600 text-white" : "hover:bg-ink-100 dark:hover:bg-ink-800"}`}>
                  {i + 1}
                </button>
              ))}
            </div>
          )}
        </div>
      ) : (
        <p className="text-ink-500">You haven&apos;t placed any orders yet.</p>
      )}
    </div>
  );
}

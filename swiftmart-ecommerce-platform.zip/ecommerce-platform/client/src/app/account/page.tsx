"use client";

import Link from "next/link";
import { Package, Heart, MapPin, LogOut, GitCompareArrows } from "lucide-react";
import { useAuthStore } from "@/store/auth.store";
import { useCurrentUser, useLogout } from "@/hooks/useAuth";
import { useMyOrders } from "@/hooks/useOrders";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

const links = [
  { href: "/account/orders", label: "My Orders", icon: Package },
  { href: "/wishlist", label: "Wishlist", icon: Heart },
  { href: "/compare", label: "Compare Products", icon: GitCompareArrows },
];

export default function AccountPage() {
  useCurrentUser();
  const { user } = useAuthStore();
  const logout = useLogout();
  const { data: orders } = useMyOrders(1);

  return (
    <div className="container py-8">
      <h1 className="mb-1 text-2xl font-bold">My Account</h1>
      <p className="mb-8 text-ink-500">Welcome back, {user?.name}</p>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
        <aside className="card h-fit space-y-1 p-3 lg:col-span-1">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium hover:bg-ink-50 dark:hover:bg-ink-800">
              <l.icon size={17} /> {l.label}
            </Link>
          ))}
          <button onClick={() => logout.mutate()} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10">
            <LogOut size={17} /> Log Out
          </button>
        </aside>

        <div className="space-y-6 lg:col-span-3">
          <div className="card p-6">
            <h3 className="mb-4 font-semibold">Recent Orders</h3>
            {orders?.data?.length ? (
              <div className="space-y-3">
                {orders.data.slice(0, 5).map((o: any) => (
                  <Link key={o.id} href={`/account/orders/${o.id}`} className="flex items-center justify-between rounded-xl border border-ink-100 p-4 text-sm hover:border-brand-300 dark:border-ink-800">
                    <div>
                      <div className="font-semibold">{o.orderNumber}</div>
                      <div className="text-ink-500">{formatDate(o.createdAt)} · {o.items.length} items</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold">{formatCurrency(o.total)}</span>
                      <Badge variant={o.status === "DELIVERED" ? "success" : o.status === "CANCELLED" ? "danger" : "warning"}>{o.status}</Badge>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-sm text-ink-500">No orders yet.</p>
            )}
          </div>

          <div className="card p-6">
            <h3 className="mb-2 font-semibold">Account Details</h3>
            <div className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
              <div><span className="text-ink-500">Name:</span> {user?.name}</div>
              <div><span className="text-ink-500">Email:</span> {user?.email}</div>
              <div><span className="text-ink-500">Role:</span> {user?.role}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

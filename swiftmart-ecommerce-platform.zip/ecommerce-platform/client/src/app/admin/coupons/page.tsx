"use client";

import { useState } from "react";
import { Plus, Ban } from "lucide-react";
import { useAdminCoupons, useCreateCoupon, useDeactivateCoupon } from "@/hooks/useAdminProducts";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency, formatDate } from "@/lib/utils";

export default function AdminCouponsPage() {
  const { data: coupons, isLoading } = useAdminCoupons();
  const createCoupon = useCreateCoupon();
  const deactivateCoupon = useDeactivateCoupon();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ code: "", type: "PERCENTAGE", value: "", minOrderAmount: "", usageLimit: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createCoupon.mutate(
      {
        code: form.code,
        type: form.type,
        value: Number(form.value),
        minOrderAmount: form.minOrderAmount ? Number(form.minOrderAmount) : undefined,
        usageLimit: form.usageLimit ? Number(form.usageLimit) : undefined,
      },
      { onSuccess: () => { setShowForm(false); setForm({ code: "", type: "PERCENTAGE", value: "", minOrderAmount: "", usageLimit: "" }); } }
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Coupons</h1>
        <Button onClick={() => setShowForm((v) => !v)}><Plus size={15} /> New Coupon</Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card grid grid-cols-2 gap-3 p-6 sm:grid-cols-4">
          <input required placeholder="Code (e.g. SAVE20)" className="input" value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} />
          <select className="input" value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))}>
            <option value="PERCENTAGE">Percentage</option>
            <option value="FIXED">Fixed Amount</option>
          </select>
          <input required type="number" placeholder="Value" className="input" value={form.value} onChange={(e) => setForm((f) => ({ ...f, value: e.target.value }))} />
          <input type="number" placeholder="Min order (optional)" className="input" value={form.minOrderAmount} onChange={(e) => setForm((f) => ({ ...f, minOrderAmount: e.target.value }))} />
          <Button type="submit" className="col-span-2 sm:col-span-4" isLoading={createCoupon.isPending}>Create Coupon</Button>
        </form>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-ink-100 text-left text-ink-500 dark:border-ink-800">
            <tr><th className="p-4">Code</th><th className="p-4">Type</th><th className="p-4">Value</th><th className="p-4">Used</th><th className="p-4">Status</th><th className="p-4"></th></tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={6} className="p-6 text-center text-ink-500">Loading...</td></tr>
            ) : coupons?.map((c: any) => (
              <tr key={c.id} className="border-b border-ink-50 last:border-0 dark:border-ink-800/50">
                <td className="p-4 font-mono font-semibold">{c.code}</td>
                <td className="p-4">{c.type}</td>
                <td className="p-4">{c.type === "PERCENTAGE" ? `${c.value}%` : formatCurrency(c.value)}</td>
                <td className="p-4">{c.usedCount}{c.usageLimit ? ` / ${c.usageLimit}` : ""}</td>
                <td className="p-4"><Badge variant={c.isActive ? "success" : "danger"}>{c.isActive ? "Active" : "Inactive"}</Badge></td>
                <td className="p-4">
                  {c.isActive && (
                    <button onClick={() => deactivateCoupon.mutate(c.id)} className="text-ink-400 hover:text-red-500"><Ban size={15} /></button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { LayoutDashboard, Package, ShoppingBag, Tag, LogOut, Store } from "lucide-react";
import { useAuthStore } from "@/store/auth.store";
import { useCurrentUser, useLogout } from "@/hooks/useAuth";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

const navItems = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { href: "/admin/coupons", label: "Coupons", icon: Tag },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  useCurrentUser();
  const { user, isHydrated } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();
  const logout = useLogout();

  useEffect(() => {
    if (isHydrated && (!user || user.role !== "ADMIN")) router.push("/login");
  }, [user, isHydrated, router]);

  if (!user || user.role !== "ADMIN") {
    return <div className="flex min-h-screen items-center justify-center text-ink-500">Checking permissions...</div>;
  }

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-ink-100 bg-ink-50/50 p-5 dark:border-ink-800 dark:bg-ink-900/40 md:flex">
        <Link href="/" className="mb-8 flex items-center gap-2 text-lg font-extrabold">
          <Store size={20} className="text-brand-600" /> SwiftMart Admin
        </Link>
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                pathname === item.href ? "bg-brand-600 text-white" : "hover:bg-ink-100 dark:hover:bg-ink-800"
              }`}
            >
              <item.icon size={17} /> {item.label}
            </Link>
          ))}
        </nav>
        <button onClick={() => logout.mutate()} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10">
          <LogOut size={17} /> Log Out
        </button>
      </aside>
      <div className="flex-1">
        <div className="flex items-center justify-between border-b border-ink-100 p-4 dark:border-ink-800 md:justify-end">
          <span className="text-sm font-medium md:hidden">Admin</span>
          <ThemeToggle />
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { useAdminAllOrders, useUpdateOrderStatus, useVerifyBankTransfer } from "@/hooks/useAdminProducts";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

const STATUSES = ["PENDING", "PAID", "PROCESSING", "SHIPPED", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED", "REFUNDED"];

const PAYMENT_METHOD_LABEL: Record<string, string> = {
  CARD: "Card", JAZZCASH: "JazzCash", BANK_TRANSFER: "Bank Transfer", COD: "Cash on Delivery",
};

export default function AdminOrdersPage() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const { data, isLoading } = useAdminAllOrders(page, statusFilter || undefined);
  const updateStatus = useUpdateOrderStatus();
  const verifyBankTransfer = useVerifyBankTransfer();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Orders</h1>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input w-auto py-2 text-sm">
          <option value="">All Statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
        </select>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-ink-100 text-left text-ink-500 dark:border-ink-800">
            <tr>
              <th className="p-4">Order #</th><th className="p-4">Customer</th><th className="p-4">Date</th>
              <th className="p-4">Payment</th><th className="p-4">Total</th><th className="p-4">Status</th><th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={7} className="p-6 text-center text-ink-500">Loading...</td></tr>
            ) : data?.data?.map((o: any) => (
              <tr key={o.id} className="border-b border-ink-50 last:border-0 dark:border-ink-800/50">
                <td className="p-4 font-medium">{o.orderNumber}</td>
                <td className="p-4 text-ink-500">{o.user.name}</td>
                <td className="p-4 text-ink-500">{formatDate(o.createdAt)}</td>
                <td className="p-4">
                  <div>{PAYMENT_METHOD_LABEL[o.paymentMethod] ?? o.paymentMethod}</div>
                  {o.paymentMethod === "BANK_TRANSFER" && (
                    <Badge variant={o.paymentStatus === "SUCCEEDED" ? "success" : "warning"}>
                      {o.paymentStatus === "SUCCEEDED" ? "Verified" : o.bankTransferReference ? "Ref submitted" : "Awaiting ref"}
                    </Badge>
                  )}
                </td>
                <td className="p-4 font-semibold">{formatCurrency(o.total)}</td>
                <td className="p-4"><Badge variant={o.status === "DELIVERED" ? "success" : o.status === "CANCELLED" ? "danger" : "warning"}>{o.status.replace(/_/g, " ")}</Badge></td>
                <td className="p-4">
                  <div className="flex flex-col gap-2">
                    {o.paymentMethod === "BANK_TRANSFER" && o.paymentStatus === "AWAITING_VERIFICATION" && (
                      <Button size="sm" variant="outline" isLoading={verifyBankTransfer.isPending} onClick={() => verifyBankTransfer.mutate(o.id)}>
                        Verify Payment
                      </Button>
                    )}
                    <select
                      defaultValue=""
                      onChange={(e) => {
                        if (!e.target.value) return;
                        updateStatus.mutate({ id: o.id, status: e.target.value, message: `Order status updated to ${e.target.value.replace(/_/g, " ")}` });
                        e.target.value = "";
                      }}
                      className="input w-auto py-1.5 text-xs"
                    >
                      <option value="">Change status...</option>
                      {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                    </select>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data?.pagination?.totalPages > 1 && (
        <div className="flex justify-center gap-2">
          {Array.from({ length: data.pagination.totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i + 1)} className={`h-9 w-9 rounded-full text-sm ${page === i + 1 ? "bg-brand-600 text-white" : "hover:bg-ink-100 dark:hover:bg-ink-800"}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

"use client";

import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { DollarSign, ShoppingBag, Users, Package, AlertTriangle } from "lucide-react";
import { useDashboardSummary, useRevenueSeries, useOrdersByStatus, useTopProducts } from "@/hooks/useAnalytics";
import { formatCurrency } from "@/lib/utils";

const COLORS = ["#f97316", "#fb923c", "#fdba74", "#fed7aa", "#94a3b8", "#64748b", "#334155", "#0f172a"];

function KpiCard({ icon: Icon, label, value, tone }: any) {
  return (
    <div className="card p-5">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-900/30">
        <Icon size={18} />
      </div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-sm text-ink-500">{label}</div>
      {tone && <div className="mt-1 text-xs text-amber-600">{tone}</div>}
    </div>
  );
}

export default function AdminDashboardPage() {
  const { data: summary } = useDashboardSummary();
  const { data: revenue } = useRevenueSeries(30);
  const { data: byStatus } = useOrdersByStatus();
  const { data: topProducts } = useTopProducts();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-ink-500">Overview of your store&apos;s performance</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <KpiCard icon={DollarSign} label="Total Revenue" value={formatCurrency(summary?.totalRevenue ?? 0)} />
        <KpiCard icon={ShoppingBag} label="Total Orders" value={summary?.totalOrders ?? 0} />
        <KpiCard icon={Users} label="Customers" value={summary?.totalCustomers ?? 0} />
        <KpiCard icon={Package} label="Active Products" value={summary?.totalProducts ?? 0} />
        <KpiCard icon={AlertTriangle} label="Low Stock Items" value={summary?.lowStockCount ?? 0} tone={summary?.lowStockCount ? "Needs attention" : undefined} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <h3 className="mb-4 font-semibold">Revenue (Last 30 Days)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={revenue}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(d) => d.slice(5)} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v: number) => formatCurrency(v)} />
              <Area type="monotone" dataKey="revenue" stroke="#f97316" fill="url(#rev)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card p-6">
          <h3 className="mb-4 font-semibold">Orders by Status</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={byStatus} dataKey="count" nameKey="status" innerRadius={55} outerRadius={90} paddingAngle={2}>
                {byStatus?.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card p-6">
        <h3 className="mb-4 font-semibold">Top Selling Products</h3>
        <div className="space-y-3">
          {topProducts?.map((p: any, i: number) => (
            <div key={p.id} className="flex items-center justify-between border-b border-ink-100 pb-3 text-sm last:border-0 dark:border-ink-800">
              <div className="flex items-center gap-3">
                <span className="w-5 text-ink-400">#{i + 1}</span>
                <span className="font-medium">{p.title}</span>
              </div>
              <div className="flex items-center gap-6 text-ink-500">
                <span>{p.totalSold} sold</span>
                <span className="font-semibold text-ink-900 dark:text-ink-100">{formatCurrency(p.price)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {summary?.lowStockProducts?.length > 0 && (
        <div className="card border-amber-200 p-6 dark:border-amber-900/50">
          <h3 className="mb-4 flex items-center gap-2 font-semibold text-amber-700 dark:text-amber-400">
            <AlertTriangle size={17} /> Low Stock Alerts
          </h3>
          <div className="space-y-2 text-sm">
            {summary.lowStockProducts.map((p: any) => (
              <div key={p.id} className="flex justify-between">
                <span>{p.title}</span>
                <span className="font-semibold text-amber-700 dark:text-amber-400">{p.stock} left</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

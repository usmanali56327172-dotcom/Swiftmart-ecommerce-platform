"use client";

import { useState, useRef } from "react";
import Image from "next/image";
import { Plus, Pencil, Trash2, Search, ImageIcon, UploadCloud, X } from "lucide-react";
import { useAdminProducts, useCreateProduct, useUpdateProduct, useDeleteProduct } from "@/hooks/useAdminProducts";
import { useCategories, useBrands } from "@/hooks/useProducts";
import { useUploadImages } from "@/hooks/useUpload";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import toast from "react-hot-toast";

const PLACEHOLDER_IMAGE = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e";

const emptyForm = {
  title: "", description: "", price: "", compareAtPrice: "", sku: "", stock: "",
  categoryId: "", brandId: "",
  thumbnail: PLACEHOLDER_IMAGE,
  // Stored as a newline-separated string in the form for easy editing;
  // split into the images[] array only when submitting.
  imagesText: PLACEHOLDER_IMAGE,
};

export default function AdminProductsPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<any>(emptyForm);

  const { data, isLoading } = useAdminProducts(page, search);
  const { data: categories } = useCategories();
  const { data: brands } = useBrands();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();
  const uploadImages = useUploadImages();
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const handleThumbnailUpload = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const urls = await uploadImages.mutateAsync([fileList[0]]);
    if (urls[0]) setForm((f: any) => ({ ...f, thumbnail: urls[0] }));
  };

  const handleGalleryUpload = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const urls = await uploadImages.mutateAsync(Array.from(fileList));
    if (urls.length) {
      setForm((f: any) => {
        const existing = f.imagesText ? f.imagesText.split("\n").filter(Boolean) : [];
        return { ...f, imagesText: [...existing, ...urls].join("\n") };
      });
      toast.success(`${urls.length} image(s) uploaded`);
    }
  };

  const removeGalleryLine = (index: number) => {
    setForm((f: any) => {
      const lines = f.imagesText.split("\n").filter(Boolean);
      lines.splice(index, 1);
      return { ...f, imagesText: lines.join("\n") };
    });
  };

  const openCreate = () => { setForm(emptyForm); setEditingId(null); setShowForm(true); };
  const openEdit = (p: any) => {
    setForm({
      title: p.title, description: p.description, price: p.price, compareAtPrice: p.compareAtPrice ?? "",
      sku: p.sku, stock: p.stock, categoryId: p.categoryId, brandId: p.brandId ?? "",
      thumbnail: p.thumbnail,
      imagesText: (p.images ?? []).join("\n"),
    });
    setEditingId(p.id);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const images = form.imagesText
      .split("\n")
      .map((s: string) => s.trim())
      .filter(Boolean);

    const payload = {
      title: form.title,
      description: form.description,
      price: Number(form.price),
      compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : undefined,
      sku: form.sku,
      stock: Number(form.stock),
      categoryId: form.categoryId,
      brandId: form.brandId || undefined,
      thumbnail: form.thumbnail || images[0] || PLACEHOLDER_IMAGE,
      images: images.length ? images : [form.thumbnail || PLACEHOLDER_IMAGE],
    };

    if (editingId) {
      updateProduct.mutate({ id: editingId, payload }, { onSuccess: () => setShowForm(false) });
    } else {
      createProduct.mutate(payload, { onSuccess: () => setShowForm(false) });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Products</h1>
        <Button onClick={openCreate}><Plus size={15} /> Add Product</Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" size={15} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products..." className="input pl-9" />
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-ink-100 text-left text-ink-500 dark:border-ink-800">
            <tr>
              <th className="p-4">Product</th><th className="p-4">SKU</th><th className="p-4">Price</th>
              <th className="p-4">Stock</th><th className="p-4">Status</th><th className="p-4"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={6} className="p-6 text-center text-ink-500">Loading...</td></tr>
            ) : data?.data?.map((p: any) => (
              <tr key={p.id} className="border-b border-ink-50 last:border-0 dark:border-ink-800/50">
                <td className="flex items-center gap-3 p-4">
                  <div className="relative h-10 w-10 overflow-hidden rounded-lg bg-ink-50 dark:bg-ink-800">
                    <Image src={p.thumbnail} alt="" fill className="object-cover" />
                  </div>
                  <span className="font-medium">{p.title}</span>
                </td>
                <td className="p-4 text-ink-500">{p.sku}</td>
                <td className="p-4">{formatCurrency(p.price)}</td>
                <td className="p-4">
                  <Badge variant={p.stock <= p.lowStockThreshold ? "warning" : "success"}>{p.stock} units</Badge>
                </td>
                <td className="p-4"><Badge variant={p.isActive ? "success" : "danger"}>{p.isActive ? "Active" : "Inactive"}</Badge></td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(p)} className="text-ink-400 hover:text-brand-600"><Pencil size={15} /></button>
                    <button onClick={() => deleteProduct.mutate(p.id)} className="text-ink-400 hover:text-red-500"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data?.pagination?.totalPages > 1 && (
        <div className="flex justify-center gap-2">
          {Array.from({ length: data.pagination.totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i + 1)} className={`h-9 w-9 rounded-full text-sm ${page === i + 1 ? "bg-brand-600 text-white" : "hover:bg-ink-100 dark:hover:bg-ink-800"}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="card max-h-[90vh] w-full max-w-2xl overflow-y-auto p-6">
            <h3 className="mb-4 text-lg font-semibold">{editingId ? "Edit Product" : "New Product"}</h3>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <input required placeholder="Title" className="input sm:col-span-2" value={form.title} onChange={(e) => setForm((f: any) => ({ ...f, title: e.target.value }))} />
              <textarea required placeholder="Description" className="input sm:col-span-2" rows={3} value={form.description} onChange={(e) => setForm((f: any) => ({ ...f, description: e.target.value }))} />
              <input required type="number" step="0.01" placeholder="Price" className="input" value={form.price} onChange={(e) => setForm((f: any) => ({ ...f, price: e.target.value }))} />
              <input type="number" step="0.01" placeholder="Compare-at price" className="input" value={form.compareAtPrice} onChange={(e) => setForm((f: any) => ({ ...f, compareAtPrice: e.target.value }))} />
              <input required placeholder="SKU" className="input" value={form.sku} onChange={(e) => setForm((f: any) => ({ ...f, sku: e.target.value }))} />
              <input required type="number" placeholder="Stock" className="input" value={form.stock} onChange={(e) => setForm((f: any) => ({ ...f, stock: e.target.value }))} />
              <select required className="input" value={form.categoryId} onChange={(e) => setForm((f: any) => ({ ...f, categoryId: e.target.value }))}>
                <option value="">Select category</option>
                {categories?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <select className="input" value={form.brandId} onChange={(e) => setForm((f: any) => ({ ...f, brandId: e.target.value }))}>
                <option value="">No brand</option>
                {brands?.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>

              {/* Photography — upload from your device, or paste an already-hosted URL. */}
              <div className="sm:col-span-2 space-y-4 rounded-xl border border-dashed border-ink-200 p-4 dark:border-ink-700">
                <div className="flex items-center gap-2 text-sm font-medium text-ink-600 dark:text-ink-300">
                  <ImageIcon size={15} /> Product Photography
                </div>

                {/* Thumbnail */}
                <div>
                  <p className="mb-1.5 text-xs font-medium text-ink-500">Thumbnail (shown on cards & search)</p>
                  <div className="flex items-start gap-3">
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-50 dark:bg-ink-800">
                      {form.thumbnail && <Image src={form.thumbnail} alt="Thumbnail preview" fill className="object-cover" />}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex gap-2">
                        <input
                          placeholder="Paste an image URL..."
                          className="input"
                          value={form.thumbnail}
                          onChange={(e) => setForm((f: any) => ({ ...f, thumbnail: e.target.value }))}
                        />
                        <input ref={thumbnailInputRef} type="file" accept="image/*" hidden onChange={(e) => handleThumbnailUpload(e.target.files)} />
                        <Button type="button" variant="outline" size="sm" isLoading={uploadImages.isPending} onClick={() => thumbnailInputRef.current?.click()}>
                          <UploadCloud size={14} /> Upload
                        </Button>
                      </div>
                      <p className="text-xs text-ink-400">JPEG, PNG, WEBP, GIF, or AVIF — up to 5MB.</p>
                    </div>
                  </div>
                </div>

                {/* Gallery */}
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <p className="text-xs font-medium text-ink-500">Gallery (product detail page)</p>
                    <div>
                      <input ref={galleryInputRef} type="file" accept="image/*" multiple hidden onChange={(e) => handleGalleryUpload(e.target.files)} />
                      <Button type="button" variant="outline" size="sm" isLoading={uploadImages.isPending} onClick={() => galleryInputRef.current?.click()}>
                        <UploadCloud size={14} /> Upload Images
                      </Button>
                    </div>
                  </div>

                  {form.imagesText.split("\n").filter(Boolean).length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-2">
                      {form.imagesText.split("\n").filter(Boolean).map((url: string, i: number) => (
                        <div key={i} className="group relative h-14 w-14 overflow-hidden rounded-lg bg-ink-50 dark:bg-ink-800">
                          <Image src={url} alt="" fill className="object-cover" />
                          <button
                            type="button"
                            onClick={() => removeGalleryLine(i)}
                            className="absolute inset-0 flex items-center justify-center bg-black/50 text-white opacity-0 transition group-hover:opacity-100"
                          >
                            <X size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <textarea
                    placeholder={`Or paste image URLs, one per line`}
                    className="input font-mono text-xs"
                    rows={2}
                    value={form.imagesText}
                    onChange={(e) => setForm((f: any) => ({ ...f, imagesText: e.target.value }))}
                  />
                  <p className="mt-1 text-xs text-ink-400">
                    Uploaded photos are added automatically — you can also paste URLs directly, one per line.
                  </p>
                </div>
              </div>

              <div className="flex gap-3 pt-2 sm:col-span-2">
                <Button type="submit" className="flex-1" isLoading={createProduct.isPending || updateProduct.isPending}>
                  {editingId ? "Save Changes" : "Create Product"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

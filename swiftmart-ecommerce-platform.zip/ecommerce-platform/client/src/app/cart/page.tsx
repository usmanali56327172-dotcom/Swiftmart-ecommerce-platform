"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Trash2, Minus, Plus, Tag, ArrowRight } from "lucide-react";
import { useCart, useUpdateCartItem, useRemoveCartItem, useApplyCoupon } from "@/hooks/useCart";
import { Button } from "@/components/ui/Button";
import { formatCurrency } from "@/lib/utils";

export default function CartPage() {
  const { data: cart, isLoading } = useCart();
  const updateItem = useUpdateCartItem();
  const removeItem = useRemoveCartItem();
  const applyCoupon = useApplyCoupon();
  const [couponCode, setCouponCode] = useState("");

  if (isLoading) return <div className="container py-16 text-center text-ink-500">Loading your cart...</div>;

  if (!cart?.items?.length) {
    return (
      <div className="container flex flex-col items-center gap-4 py-24 text-center">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <p className="text-ink-500">Looks like you haven&apos;t added anything yet.</p>
        <Link href="/products" className="btn-primary">Start Shopping</Link>
      </div>
    );
  }

  const totals = cart.totals;

  return (
    <div className="container py-8">
      <h1 className="mb-6 text-2xl font-bold">Shopping Cart</h1>
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {cart.items.map((item: any) => (
            <div key={item.id} className="card flex gap-4 p-4">
              <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-800">
                <Image src={item.product.thumbnail} alt={item.product.title} fill className="object-cover" />
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div className="flex items-start justify-between">
                  <Link href={`/products/${item.product.slug}`} className="font-semibold hover:text-brand-600">{item.product.title}</Link>
                  <button onClick={() => removeItem.mutate(item.productId)} className="text-ink-400 hover:text-red-500">
                    <Trash2 size={17} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center rounded-full border border-ink-200 dark:border-ink-700">
                    <button
                      onClick={() => updateItem.mutate({ productId: item.productId, quantity: item.quantity - 1 })}
                      className="flex h-8 w-8 items-center justify-center"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="w-7 text-center text-sm">{item.quantity}</span>
                    <button
                      onClick={() => updateItem.mutate({ productId: item.productId, quantity: item.quantity + 1 })}
                      className="flex h-8 w-8 items-center justify-center"
                    >
                      <Plus size={13} />
                    </button>
                  </div>
                  <span className="font-bold">{formatCurrency(Number(item.product.price) * item.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="card h-fit space-y-4 p-6">
          <h3 className="font-semibold">Order Summary</h3>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" size={15} />
              <input
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                placeholder="Coupon code"
                className="input pl-9 text-sm"
              />
            </div>
            <Button variant="outline" onClick={() => applyCoupon.mutate(couponCode)} isLoading={applyCoupon.isPending}>Apply</Button>
          </div>

          <div className="space-y-2 border-t border-ink-100 pt-4 text-sm dark:border-ink-800">
            <div className="flex justify-between"><span className="text-ink-500">Subtotal</span><span>{formatCurrency(totals.subtotal)}</span></div>
            {totals.discount > 0 && (
              <div className="flex justify-between text-emerald-600"><span>Discount</span><span>-{formatCurrency(totals.discount)}</span></div>
            )}
            <div className="flex justify-between"><span className="text-ink-500">Shipping</span><span>{totals.shippingFee === 0 ? "Free" : formatCurrency(totals.shippingFee)}</span></div>
            <div className="flex justify-between"><span className="text-ink-500">Tax</span><span>{formatCurrency(totals.tax)}</span></div>
          </div>
          <div className="flex justify-between border-t border-ink-100 pt-4 text-lg font-bold dark:border-ink-800">
            <span>Total</span><span>{formatCurrency(totals.total)}</span>
          </div>

          <Link href="/checkout" className="btn-primary w-full">
            Proceed to Checkout <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}

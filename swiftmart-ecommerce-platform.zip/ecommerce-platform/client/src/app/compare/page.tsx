"use client";

import Image from "next/image";
import { X } from "lucide-react";
import { useCompareList, useToggleCompare } from "@/hooks/useCompare";
import { formatCurrency } from "@/lib/utils";
import { Rating } from "@/components/ui/Rating";

export default function ComparePage() {
  const { data: items, isLoading } = useCompareList();
  const { remove } = useToggleCompare();

  if (isLoading) return <div className="container py-16 text-center text-ink-500">Loading comparison...</div>;

  if (!items?.length) {
    return (
      <div className="container py-16 text-center text-ink-500">
        No products to compare yet. Add up to 4 products from the catalog to compare them side by side.
      </div>
    );
  }

  const attributeKeys = Array.from(
    new Set(items.flatMap((i: any) => Object.keys(i.product.attributes ?? {})))
  );

  return (
    <div className="container py-8">
      <h1 className="mb-6 text-2xl font-bold">Compare Products</h1>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[700px] border-separate border-spacing-x-4">
          <thead>
            <tr>
              <td className="w-32"></td>
              {items.map((i: any) => (
                <td key={i.id} className="align-top">
                  <div className="card relative p-4 text-center">
                    <button onClick={() => remove.mutate(i.productId)} className="absolute right-2 top-2 text-ink-400 hover:text-red-500">
                      <X size={15} />
                    </button>
                    <div className="relative mx-auto mb-3 h-28 w-28 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-800">
                      <Image src={i.product.thumbnail} alt={i.product.title} fill className="object-cover" />
                    </div>
                    <div className="text-sm font-semibold">{i.product.title}</div>
                  </div>
                </td>
              ))}
            </tr>
          </thead>
          <tbody className="text-sm">
            <tr>
              <td className="py-3 font-medium text-ink-500">Price</td>
              {items.map((i: any) => <td key={i.id} className="py-3 text-center font-bold">{formatCurrency(i.product.price)}</td>)}
            </tr>
            <tr>
              <td className="py-3 font-medium text-ink-500">Rating</td>
              {items.map((i: any) => <td key={i.id} className="py-3 text-center"><div className="flex justify-center"><Rating value={i.product.avgRating} count={i.product.reviewCount} /></div></td>)}
            </tr>
            <tr>
              <td className="py-3 font-medium text-ink-500">Brand</td>
              {items.map((i: any) => <td key={i.id} className="py-3 text-center">{i.product.brand?.name ?? "—"}</td>)}
            </tr>
            <tr>
              <td className="py-3 font-medium text-ink-500">Stock</td>
              {items.map((i: any) => <td key={i.id} className="py-3 text-center">{i.product.stock > 0 ? `${i.product.stock} available` : "Out of stock"}</td>)}
            </tr>
            {attributeKeys.map((key) => (
              <tr key={key}>
                <td className="py-3 font-medium capitalize text-ink-500">{key}</td>
                {items.map((i: any) => <td key={i.id} className="py-3 text-center">{i.product.attributes?.[key] ?? "—"}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

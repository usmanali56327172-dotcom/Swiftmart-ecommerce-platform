import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";
import { TopBar } from "@/components/layout/TopBar";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: {
    default: "SwiftMart — Shop Smarter, Delivered Fast",
    template: "%s · SwiftMart",
  },
  description:
    "SwiftMart is Pakistan's premium online marketplace — curated electronics, fashion, home goods and more, with card, JazzCash, bank transfer and Cash on Delivery, real-time order tracking, and hassle-free returns.",
  keywords: ["online shopping Pakistan", "SwiftMart", "e-commerce", "JazzCash payment", "online store"],
  openGraph: {
    title: "SwiftMart — Shop Smarter, Delivered Fast",
    description: "Curated products, fast delivery, and a checkout you can trust.",
    siteName: "SwiftMart",
    type: "website",
  },
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <Providers>
          <div className="flex min-h-screen flex-col">
            <TopBar />
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
        </Providers>
      </body>
    </html>
  );
}

"use client";

import { useState } from "react";
import Link from "next/link";
import { useLogin } from "@/hooks/useAuth";
import { Button } from "@/components/ui/Button";

export default function LoginPage() {
  const [form, setForm] = useState({ email: "", password: "" });
  const login = useLogin();

  return (
    <div className="container flex min-h-[70vh] items-center justify-center py-12">
      <div className="card w-full max-w-md p-8">
        <h1 className="mb-1 text-2xl font-bold">Welcome back</h1>
        <p className="mb-6 text-sm text-ink-500">Log in to continue shopping</p>
        <form
          onSubmit={(e) => { e.preventDefault(); login.mutate(form); }}
          className="space-y-4"
        >
          <div>
            <label className="mb-1.5 block text-sm font-medium">Email</label>
            <input type="email" required className="input" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium">Password</label>
            <input type="password" required className="input" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
          </div>
          <Button type="submit" className="w-full" size="lg" isLoading={login.isPending}>Log In</Button>
        </form>
        <p className="mt-4 text-center text-sm text-ink-500">
          New here? <Link href="/register" className="font-semibold text-brand-600">Create an account</Link>
        </p>
        <div className="mt-6 rounded-xl bg-ink-50 p-3 text-xs text-ink-500 dark:bg-ink-800">
          Demo accounts — Admin: admin@swiftmart.com / Password1 · Customer: customer@swiftmart.com / Password1
        </div>
      </div>
    </div>
  );
}

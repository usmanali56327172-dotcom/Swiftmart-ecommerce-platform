"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Truck, ShieldCheck, RotateCcw, Headphones, Star, Mail, CheckCircle2 } from "lucide-react";
import { useProducts, useCategories, useBrands } from "@/hooks/useProducts";
import { ProductCard } from "@/components/product/ProductCard";
import { ProductGridSkeleton } from "@/components/product/ProductGridSkeleton";
import { Button } from "@/components/ui/Button";
import toast from "react-hot-toast";

const perks = [
  { icon: Truck, title: "Free Shipping", desc: "On orders over Rs. 5,000" },
  { icon: ShieldCheck, title: "Secure Payments", desc: "Card, JazzCash, bank transfer & COD" },
  { icon: RotateCcw, title: "Easy Returns", desc: "30-day return window" },
  { icon: Headphones, title: "24/7 Support", desc: "We're here when you need us" },
];

const testimonials = [
  { name: "Ayesha K.", role: "Verified Buyer, Lahore", quote: "Ordering was effortless and my package arrived two days early. The order tracking kept me updated the whole way.", rating: 5 },
  { name: "Bilal A.", role: "Verified Buyer, Karachi", quote: "Paid with JazzCash in seconds — no fuss, no hidden charges. Will definitely shop here again.", rating: 5 },
  { name: "Sana M.", role: "Verified Buyer, Islamabad", quote: "Great prices and the quality matched the photos exactly. Customer support responded within minutes.", rating: 4 },
];

export default function HomePage() {
  const { data: featured, isLoading } = useProducts({ limit: 8, sort: "popular" });
  const { data: newArrivals } = useProducts({ limit: 4, sort: "newest" });
  const { data: categories } = useCategories();
  const { data: brands } = useBrands();
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) return toast.error("Enter a valid email address");
    setSubscribed(true);
    toast.success("You're subscribed! Watch for our next deal.");
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-ink-950 via-ink-900 to-brand-900">
        <div className="container relative z-10 flex flex-col items-start gap-6 py-24 md:py-32">
          <span className="animate-fade-up rounded-full bg-white/10 px-4 py-1.5 text-xs font-medium text-brand-200 backdrop-blur">
            Pakistan's Trusted Online Marketplace
          </span>
          <h1 className="animate-fade-up max-w-2xl text-4xl font-extrabold leading-tight text-white md:text-6xl" style={{ animationDelay: "0.05s" }}>
            Shop smarter. <span className="text-brand-400">Delivered fast.</span>
          </h1>
          <p className="animate-fade-up max-w-lg text-lg text-ink-300" style={{ animationDelay: "0.1s" }}>
            Curated electronics, fashion, home goods and more — pay by card, JazzCash, bank
            transfer or Cash on Delivery, with real-time tracking every step of the way.
          </p>
          <div className="animate-fade-up flex flex-wrap gap-3" style={{ animationDelay: "0.15s" }}>
            <Link href="/products" className="btn-primary text-base">
              Shop the Collection <ArrowRight size={18} />
            </Link>
            <Link href="/products?sort=rating" className="btn text-base border border-white/20 text-white hover:bg-white/10">
              Top Rated Products
            </Link>
          </div>
          <div className="animate-fade-up mt-4 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-ink-300" style={{ animationDelay: "0.2s" }}>
            <span className="flex items-center gap-1.5"><CheckCircle2 size={15} className="text-brand-400" /> 50,000+ orders delivered</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 size={15} className="text-brand-400" /> 4.7/5 average rating</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 size={15} className="text-brand-400" /> Nationwide delivery</span>
          </div>
        </div>
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-500/20 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-brand-600/10 blur-3xl" />
      </section>

      {/* Perks */}
      <section className="border-b border-ink-100 dark:border-ink-800">
        <div className="container grid grid-cols-2 gap-6 py-10 md:grid-cols-4">
          {perks.map((p) => (
            <div key={p.title} className="flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600 dark:bg-brand-900/30">
                <p.icon size={20} />
              </div>
              <div>
                <div className="text-sm font-semibold">{p.title}</div>
                <div className="text-xs text-ink-500">{p.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="container py-14">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold">Shop by Category</h2>
            <p className="text-sm text-ink-500">Find exactly what you're looking for</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
          {categories?.map((c: any) => (
            <Link
              key={c.id}
              href={`/products?category=${c.slug}`}
              className="group card flex flex-col items-center gap-3 p-6 text-center transition hover:-translate-y-1 hover:shadow-md"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-2xl font-bold text-brand-600 dark:bg-brand-900/30">
                {c.name.charAt(0)}
              </div>
              <span className="text-sm font-medium group-hover:text-brand-600">{c.name}</span>
              <span className="text-xs text-ink-400">{c._count?.products ?? 0} items</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="container pb-14">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Trending Now</h2>
            <p className="text-sm text-ink-500">Our best-selling products this week</p>
          </div>
          <Link href="/products?sort=popular" className="flex items-center gap-1 text-sm font-semibold text-brand-600 hover:underline">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {isLoading ? (
          <ProductGridSkeleton />
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {featured?.data?.map((p: any) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </section>

      {/* Promo banner */}
      <section className="container pb-14">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-brand-600 to-brand-500 px-8 py-14 text-white md:px-16">
          <h3 className="max-w-md text-3xl font-extrabold">Get 10% off your first order</h3>
          <p className="mt-2 max-w-md text-brand-50">Use code <strong>WELCOME10</strong> at checkout on orders over Rs. 3,000.</p>
          <Link href="/products" className="mt-6 inline-block rounded-full bg-white px-6 py-3 text-sm font-bold text-brand-700 hover:bg-brand-50">
            Start Shopping
          </Link>
          <div className="absolute -right-10 -top-10 h-56 w-56 rounded-full bg-white/10" />
        </div>
      </section>

      {/* New arrivals */}
      {newArrivals?.data?.length > 0 && (
        <section className="container pb-14">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">New Arrivals</h2>
              <p className="text-sm text-ink-500">Just added to the catalog</p>
            </div>
            <Link href="/products?sort=newest" className="flex items-center gap-1 text-sm font-semibold text-brand-600 hover:underline">
              View all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {newArrivals.data.map((p: any) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {/* Brand strip */}
      {brands?.length > 0 && (
        <section className="border-y border-ink-100 bg-ink-50/50 py-10 dark:border-ink-800 dark:bg-ink-900/30">
          <div className="container">
            <p className="mb-6 text-center text-sm font-medium text-ink-500">Trusted by shoppers who love these brands</p>
            <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
              {brands.map((b: any) => (
                <Link key={b.id} href={`/products?brand=${b.slug}`} className="text-lg font-bold text-ink-400 transition hover:text-brand-600">
                  {b.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Testimonials */}
      <section className="container py-16">
        <div className="mb-10 text-center">
          <h2 className="text-2xl font-bold">What Our Customers Say</h2>
          <p className="text-sm text-ink-500">Real reviews from verified buyers across Pakistan</p>
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="card p-6">
              <div className="mb-3 flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={15} className={i < t.rating ? "fill-brand-500 text-brand-500" : "fill-ink-200 text-ink-200 dark:fill-ink-700 dark:text-ink-700"} />
                ))}
              </div>
              <p className="text-sm text-ink-600 dark:text-ink-300">&ldquo;{t.quote}&rdquo;</p>
              <div className="mt-4 text-sm font-semibold">{t.name}</div>
              <div className="text-xs text-ink-400">{t.role}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="container pb-20">
        <div className="card flex flex-col items-center gap-4 p-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-600 dark:bg-brand-900/30">
            <Mail size={20} />
          </div>
          <h3 className="text-xl font-bold">Get exclusive deals in your inbox</h3>
          <p className="max-w-md text-sm text-ink-500">
            Subscribe for early access to sales, new arrivals, and members-only coupon codes. No spam, unsubscribe anytime.
          </p>
          {subscribed ? (
            <p className="flex items-center gap-2 text-sm font-medium text-emerald-600"><CheckCircle2 size={16} /> Thanks — check your inbox soon!</p>
          ) : (
            <form onSubmit={handleSubscribe} className="flex w-full max-w-sm gap-2">
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input"
              />
              <Button type="submit">Subscribe</Button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}

"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
import { Heart, GitCompareArrows, ShieldCheck, Truck, Minus, Plus } from "lucide-react";
import { useProduct } from "@/hooks/useProducts";
import { useProductReviews, useCreateReview } from "@/hooks/useReviews";
import { Rating } from "@/components/ui/Rating";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProductCard } from "@/components/product/ProductCard";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useAddToCart } from "@/hooks/useCart";
import { useToggleWishlist } from "@/hooks/useWishlist";
import { useToggleCompare } from "@/hooks/useCompare";
import { useAuthStore } from "@/store/auth.store";
import { useRouter } from "next/navigation";

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data, isLoading } = useProduct(slug);
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: "", comment: "" });

  const addToCart = useAddToCart();
  const { add: addToWishlist } = useToggleWishlist();
  const { add: addToCompare } = useToggleCompare();
  const { accessToken } = useAuthStore();
  const router = useRouter();

  const product = data?.product;
  const { data: reviews } = useProductReviews(product?.id ?? "");
  const createReview = useCreateReview(product?.id ?? "");

  const guard = (fn: () => void) => (!accessToken ? router.push("/login") : fn());

  if (isLoading || !product) {
    return <div className="container py-16 text-center text-ink-500">Loading product...</div>;
  }

  const discount = product.compareAtPrice
    ? Math.round((1 - Number(product.price) / Number(product.compareAtPrice)) * 100)
    : 0;

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="relative aspect-square overflow-hidden rounded-2xl bg-ink-50 dark:bg-ink-800">
            <Image src={product.images[activeImage]} alt={product.title} fill className="object-cover" priority />
            {discount > 0 && <Badge variant="danger" className="absolute left-4 top-4">-{discount}% OFF</Badge>}
          </div>
          <div className="mt-3 flex gap-3">
            {product.images.map((img: string, i: number) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={`relative h-20 w-20 overflow-hidden rounded-xl border-2 ${activeImage === i ? "border-brand-500" : "border-transparent"}`}
              >
                <Image src={img} alt="" fill className="object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div>
          {product.brand && <div className="mb-1 text-sm font-medium uppercase tracking-wide text-brand-600">{product.brand.name}</div>}
          <h1 className="text-3xl font-bold">{product.title}</h1>
          <div className="mt-3 flex items-center gap-3">
            <Rating value={product.avgRating} count={product.reviewCount} />
            {product.stock > 0 ? <Badge variant="success">In Stock</Badge> : <Badge variant="danger">Out of Stock</Badge>}
          </div>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="text-4xl font-extrabold">{formatCurrency(product.price)}</span>
            {product.compareAtPrice && <span className="text-lg text-ink-400 line-through">{formatCurrency(product.compareAtPrice)}</span>}
          </div>

          <p className="mt-5 text-ink-600 dark:text-ink-300">{product.description}</p>

          {product.attributes && Object.keys(product.attributes).length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {Object.entries(product.attributes).map(([k, v]) => (
                <span key={k} className="rounded-full border border-ink-200 px-3 py-1 text-xs dark:border-ink-700">
                  {k}: <strong>{String(v)}</strong>
                </span>
              ))}
            </div>
          )}

          <div className="mt-6 flex items-center gap-4">
            <div className="flex items-center rounded-full border border-ink-200 dark:border-ink-700">
              <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="flex h-10 w-10 items-center justify-center">
                <Minus size={15} />
              </button>
              <span className="w-8 text-center font-medium">{quantity}</span>
              <button onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))} className="flex h-10 w-10 items-center justify-center">
                <Plus size={15} />
              </button>
            </div>
            <Button
              className="flex-1"
              size="lg"
              disabled={product.stock === 0}
              isLoading={addToCart.isPending}
              onClick={() => guard(() => addToCart.mutate({ productId: product.id, quantity }))}
            >
              Add to Cart
            </Button>
          </div>

          <div className="mt-4 flex gap-3">
            <button onClick={() => guard(() => addToWishlist.mutate(product.id))} className="btn-outline flex-1">
              <Heart size={15} /> Wishlist
            </button>
            <button onClick={() => guard(() => addToCompare.mutate(product.id))} className="btn-outline flex-1">
              <GitCompareArrows size={15} /> Compare
            </button>
          </div>

          <div className="mt-6 space-y-2 rounded-2xl border border-ink-100 p-4 text-sm dark:border-ink-800">
            <div className="flex items-center gap-2 text-ink-600 dark:text-ink-300"><Truck size={16} /> Free shipping on orders over Rs. 5,000</div>
            <div className="flex items-center gap-2 text-ink-600 dark:text-ink-300"><ShieldCheck size={16} /> Secure checkout & 30-day returns</div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-16">
        <h2 className="mb-6 text-2xl font-bold">Customer Reviews</h2>
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            {reviews?.length ? (
              reviews.map((r: any) => (
                <div key={r.id} className="border-b border-ink-100 pb-6 dark:border-ink-800">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{r.user.name}</div>
                      <Rating value={r.rating} size={13} />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-ink-400">
                      {r.isVerifiedPurchase && <Badge variant="success">Verified Purchase</Badge>}
                      {formatDate(r.createdAt)}
                    </div>
                  </div>
                  {r.title && <div className="mt-2 font-medium">{r.title}</div>}
                  <p className="mt-1 text-sm text-ink-600 dark:text-ink-300">{r.comment}</p>
                </div>
              ))
            ) : (
              <p className="text-ink-500">No reviews yet — be the first to share your thoughts.</p>
            )}
          </div>

          <div className="card h-fit p-5">
            <h3 className="mb-4 font-semibold">Write a Review</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                guard(() => createReview.mutate(reviewForm, { onSuccess: () => setReviewForm({ rating: 5, title: "", comment: "" }) }));
              }}
              className="space-y-3"
            >
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button type="button" key={n} onClick={() => setReviewForm((f) => ({ ...f, rating: n }))}>
                    <Rating value={n <= reviewForm.rating ? 5 : 0} size={20} />
                  </button>
                ))}
              </div>
              <input
                placeholder="Title (optional)"
                value={reviewForm.title}
                onChange={(e) => setReviewForm((f) => ({ ...f, title: e.target.value }))}
                className="input"
              />
              <textarea
                placeholder="Share your experience..."
                value={reviewForm.comment}
                onChange={(e) => setReviewForm((f) => ({ ...f, comment: e.target.value }))}
                required
                minLength={5}
                rows={4}
                className="input"
              />
              <Button type="submit" className="w-full" isLoading={createReview.isPending}>Submit Review</Button>
            </form>
          </div>
        </div>
      </section>

      {/* Related */}
      {data.related?.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-bold">You Might Also Like</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {data.related.map((p: any) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}

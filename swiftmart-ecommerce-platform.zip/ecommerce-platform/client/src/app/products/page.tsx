"use client";

import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { SlidersHorizontal } from "lucide-react";
import { useProducts } from "@/hooks/useProducts";
import { ProductCard } from "@/components/product/ProductCard";
import { ProductGridSkeleton } from "@/components/product/ProductGridSkeleton";
import { ProductFilters } from "@/components/product/ProductFilters";

export default function ProductsPage() {
  const params = useSearchParams();
  const router = useRouter();
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);

  const filters = {
    search: params.get("search") || undefined,
    category: params.get("category") || undefined,
    brand: params.get("brand") || undefined,
    minPrice: params.get("minPrice") ? Number(params.get("minPrice")) : undefined,
    maxPrice: params.get("maxPrice") ? Number(params.get("maxPrice")) : undefined,
    rating: params.get("rating") ? Number(params.get("rating")) : undefined,
    inStock: params.get("inStock") === "true" || undefined,
    sort: params.get("sort") || undefined,
    page,
    limit: 12,
  };

  const { data, isLoading } = useProducts(filters);

  const updateFilters = (patch: Record<string, any>) => {
    const next = new URLSearchParams(params.toString());
    Object.entries(patch).forEach(([k, v]) => {
      if (v === undefined || v === null || v === "") next.delete(k);
      else next.set(k, String(v));
    });
    setPage(1);
    router.push(`/products?${next.toString()}`);
  };

  return (
    <div className="container py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{filters.search ? `Results for "${filters.search}"` : "All Products"}</h1>
          {data?.pagination && <p className="text-sm text-ink-500">{data.pagination.total} products found</p>}
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setShowFilters((v) => !v)} className="btn-outline lg:hidden">
            <SlidersHorizontal size={15} /> Filters
          </button>
          <select
            value={filters.sort || "newest"}
            onChange={(e) => updateFilters({ sort: e.target.value })}
            className="input w-auto py-2 text-sm"
          >
            <option value="newest">Newest</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-8 lg:flex-row">
        <div className={showFilters ? "block" : "hidden lg:block"}>
          <ProductFilters filters={filters} onChange={updateFilters} />
        </div>

        <div className="flex-1">
          {isLoading ? (
            <ProductGridSkeleton count={12} />
          ) : data?.data?.length ? (
            <>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
                {data.data.map((p: any) => <ProductCard key={p.id} product={p} />)}
              </div>
              {data.pagination.totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center gap-2">
                  {Array.from({ length: data.pagination.totalPages }).map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setPage(i + 1)}
                      className={`h-9 w-9 rounded-full text-sm ${page === i + 1 ? "bg-brand-600 text-white" : "hover:bg-ink-100 dark:hover:bg-ink-800"}`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center gap-2 py-24 text-center text-ink-500">
              <p className="text-lg font-medium">No products match your filters</p>
              <p className="text-sm">Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import Link from "next/link";
import { useRegister } from "@/hooks/useAuth";
import { Button } from "@/components/ui/Button";

export default function RegisterPage() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const register = useRegister();

  return (
    <div className="container flex min-h-[70vh] items-center justify-center py-12">
      <div className="card w-full max-w-md p-8">
        <h1 className="mb-1 text-2xl font-bold">Create your account</h1>
        <p className="mb-6 text-sm text-ink-500">Join SwiftMart in seconds</p>
        <form onSubmit={(e) => { e.preventDefault(); register.mutate(form); }} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium">Full Name</label>
            <input required className="input" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium">Email</label>
            <input type="email" required className="input" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium">Password</label>
            <input type="password" required minLength={8} className="input" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
            <p className="mt-1 text-xs text-ink-400">At least 8 characters, one uppercase letter, one number.</p>
          </div>
          <Button type="submit" className="w-full" size="lg" isLoading={register.isPending}>Create Account</Button>
        </form>
        <p className="mt-4 text-center text-sm text-ink-500">
          Already have an account? <Link href="/login" className="font-semibold text-brand-600">Log in</Link>
        </p>
      </div>
    </div>
  );
}

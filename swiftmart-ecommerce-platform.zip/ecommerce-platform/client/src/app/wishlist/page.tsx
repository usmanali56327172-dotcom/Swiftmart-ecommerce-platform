"use client";

import { useWishlist, useToggleWishlist } from "@/hooks/useWishlist";
import { useAddToCart } from "@/hooks/useCart";
import { ProductCard } from "@/components/product/ProductCard";

export default function WishlistPage() {
  const { data: wishlist, isLoading } = useWishlist();

  if (isLoading) return <div className="container py-16 text-center text-ink-500">Loading wishlist...</div>;

  return (
    <div className="container py-8">
      <h1 className="mb-6 text-2xl font-bold">My Wishlist</h1>
      {wishlist?.items?.length ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {wishlist.items.map((item: any) => <ProductCard key={item.id} product={item.product} />)}
        </div>
      ) : (
        <p className="text-ink-500">Your wishlist is empty. Start adding products you love!</p>
      )}
    </div>
  );
}

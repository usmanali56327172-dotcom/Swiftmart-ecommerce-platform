import Link from "next/link";
import { Facebook, Instagram, Twitter, Youtube, Mail, MapPin, Phone, ShieldCheck, CreditCard, Smartphone, Landmark, Truck } from "lucide-react";

const columns = [
  { title: "Shop", links: [["All Products", "/products"], ["Categories", "/products"], ["Best Deals", "/products?sort=price_asc"], ["New Arrivals", "/products?sort=newest"]] },
  { title: "Account", links: [["My Orders", "/account/orders"], ["Wishlist", "/wishlist"], ["Compare", "/compare"], ["Track Order", "/account/orders"]] },
  { title: "Company", links: [["About Us", "#"], ["Careers", "#"], ["Press", "#"], ["Contact", "#"]] },
  { title: "Support", links: [["Shipping Policy", "#"], ["Returns & Refunds", "#"], ["FAQs", "#"], ["Terms & Privacy", "#"]] },
];

const paymentMethods = [
  { label: "Card", icon: CreditCard },
  { label: "JazzCash", icon: Smartphone },
  { label: "Bank Transfer", icon: Landmark },
  { label: "Cash on Delivery", icon: Truck },
];

export function Footer() {
  return (
    <footer className="border-t border-ink-100 bg-ink-50/50 dark:border-ink-800 dark:bg-ink-900/40">
      {/* Trust strip */}
      <div className="border-b border-ink-100 dark:border-ink-800">
        <div className="container grid grid-cols-2 gap-6 py-8 sm:grid-cols-4">
          <div className="flex items-center gap-3">
            <Truck size={20} className="shrink-0 text-brand-600" />
            <div>
              <div className="text-sm font-semibold">Nationwide Delivery</div>
              <div className="text-xs text-ink-500">All major cities in Pakistan</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ShieldCheck size={20} className="shrink-0 text-brand-600" />
            <div>
              <div className="text-sm font-semibold">Secure Checkout</div>
              <div className="text-xs text-ink-500">Encrypted payments, every time</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <CreditCard size={20} className="shrink-0 text-brand-600" />
            <div>
              <div className="text-sm font-semibold">Flexible Payments</div>
              <div className="text-xs text-ink-500">Card, JazzCash, bank transfer, COD</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Phone size={20} className="shrink-0 text-brand-600" />
            <div>
              <div className="text-sm font-semibold">Dedicated Support</div>
              <div className="text-xs text-ink-500">Mon–Sat, 9am–8pm</div>
            </div>
          </div>
        </div>
      </div>

      <div className="container grid grid-cols-2 gap-8 py-12 md:grid-cols-6">
        <div className="col-span-2 md:col-span-2">
          <div className="mb-3 text-xl font-extrabold"><span className="text-brand-600">Swift</span>Mart</div>
          <p className="max-w-xs text-sm text-ink-500">
            A premium shopping experience — curated products, fast and reliable delivery, and a checkout you can trust.
          </p>
          <div className="mt-4 space-y-1.5 text-sm text-ink-500">
            <div className="flex items-center gap-2"><MapPin size={14} /> Lahore, Pakistan</div>
            <div className="flex items-center gap-2"><Mail size={14} /> support@swiftmart.pk</div>
            <div className="flex items-center gap-2"><Phone size={14} /> +92 300 1234567</div>
          </div>
          <div className="mt-4 flex gap-3">
            {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
              <a key={i} href="#" className="flex h-8 w-8 items-center justify-center rounded-full border border-ink-200 text-ink-500 hover:border-brand-500 hover:text-brand-600 dark:border-ink-700">
                <Icon size={14} />
              </a>
            ))}
          </div>
        </div>
        {columns.map((col) => (
          <div key={col.title}>
            <h4 className="mb-3 text-sm font-semibold">{col.title}</h4>
            <ul className="space-y-2">
              {col.links.map(([label, href]) => (
                <li key={label}>
                  <Link href={href} className="text-sm text-ink-500 hover:text-brand-600">{label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-ink-100 py-6 dark:border-ink-800">
        <div className="container flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="text-xs text-ink-400">© {new Date().getFullYear()} SwiftMart Retail (Pvt) Ltd. All rights reserved.</p>
          <div className="flex items-center gap-3">
            {paymentMethods.map((p) => (
              <span key={p.label} className="flex items-center gap-1.5 rounded-md border border-ink-200 px-2.5 py-1 text-[11px] text-ink-500 dark:border-ink-700">
                <p.icon size={12} /> {p.label}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

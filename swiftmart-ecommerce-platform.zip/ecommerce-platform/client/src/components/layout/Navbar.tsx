"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Search, ShoppingCart, Heart, User, Menu, X, LayoutGrid } from "lucide-react";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { useAuthStore } from "@/store/auth.store";
import { useCurrentUser } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  const { user } = useAuthStore();
  useCurrentUser();
  const { data: cart } = useCart();
  const { data: wishlist } = useWishlist();

  const cartCount = cart?.items?.reduce((n: number, i: any) => n + i.quantity, 0) ?? 0;
  const wishlistCount = wishlist?.items?.length ?? 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(query ? `/products?search=${encodeURIComponent(query)}` : "/products");
  };

  const isAdminRoute = pathname?.startsWith("/admin");
  if (isAdminRoute) return null;

  return (
    <header className="sticky top-0 z-40 border-b border-ink-100 bg-white/80 backdrop-blur-lg dark:border-ink-800 dark:bg-ink-950/80">
      <div className="container flex h-16 items-center gap-4">
        <button className="md:hidden" onClick={() => setMobileOpen((v) => !v)} aria-label="Toggle menu">
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        <Link href="/" className="flex items-center gap-1.5 text-xl font-extrabold tracking-tight">
          <span className="text-brand-600">Swift</span>Mart
        </Link>

        <Link href="/products" className="hidden items-center gap-1.5 text-sm font-medium text-ink-600 hover:text-brand-600 dark:text-ink-300 md:flex">
          <LayoutGrid size={16} /> Catalog
        </Link>

        <form onSubmit={handleSearch} className="mx-auto hidden max-w-xl flex-1 md:block">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" size={17} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products, brands, categories..."
              className="input pl-10"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-1.5 sm:gap-3">
          <ThemeToggle />
          <Link href="/wishlist" className="relative flex h-9 w-9 items-center justify-center rounded-full hover:bg-ink-100 dark:hover:bg-ink-800" aria-label="Wishlist">
            <Heart size={19} />
            {wishlistCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-brand-600 text-[10px] font-bold text-white">
                {wishlistCount}
              </span>
            )}
          </Link>
          <Link href="/cart" className="relative flex h-9 w-9 items-center justify-center rounded-full hover:bg-ink-100 dark:hover:bg-ink-800" aria-label="Cart">
            <ShoppingCart size={19} />
            {cartCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-brand-600 text-[10px] font-bold text-white">
                {cartCount}
              </span>
            )}
          </Link>
          <Link
            href={user ? "/account" : "/login"}
            className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-ink-100 dark:hover:bg-ink-800"
            aria-label="Account"
          >
            <User size={19} />
          </Link>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-ink-100 p-4 dark:border-ink-800 md:hidden">
          <form onSubmit={handleSearch} className="mb-3">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" size={17} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search..." className="input pl-10" />
            </div>
          </form>
          <Link href="/products" className={cn("block py-2 text-sm font-medium")} onClick={() => setMobileOpen(false)}>
            Catalog
          </Link>
        </div>
      )}
    </header>
  );
}

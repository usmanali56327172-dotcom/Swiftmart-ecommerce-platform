"use client";

import { Truck, ShieldCheck, Phone } from "lucide-react";

export function TopBar() {
  return (
    <div className="hidden bg-ink-950 text-ink-200 md:block">
      <div className="container flex h-9 items-center justify-between text-xs">
        <div className="flex items-center gap-5">
          <span className="flex items-center gap-1.5"><Truck size={13} /> Free delivery on orders over Rs. 5,000</span>
          <span className="flex items-center gap-1.5"><ShieldCheck size={13} /> 100% secure checkout</span>
        </div>
        <div className="flex items-center gap-5">
          <span className="flex items-center gap-1.5"><Phone size={13} /> +92 300 1234567</span>
          <span>Deliver to: Pakistan</span>
        </div>
      </div>
    </div>
  );
}

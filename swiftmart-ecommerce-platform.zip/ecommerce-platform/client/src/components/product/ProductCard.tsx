"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, GitCompareArrows, ShoppingCart } from "lucide-react";
import { Rating } from "@/components/ui/Rating";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency, cn } from "@/lib/utils";
import { useAddToCart } from "@/hooks/useCart";
import { useToggleWishlist } from "@/hooks/useWishlist";
import { useToggleCompare } from "@/hooks/useCompare";
import { useAuthStore } from "@/store/auth.store";
import { useRouter } from "next/navigation";

export function ProductCard({ product }: { product: any }) {
  const addToCart = useAddToCart();
  const { add: addToWishlist } = useToggleWishlist();
  const { add: addToCompare } = useToggleCompare();
  const { accessToken } = useAuthStore();
  const router = useRouter();

  const discount = product.compareAtPrice
    ? Math.round((1 - Number(product.price) / Number(product.compareAtPrice)) * 100)
    : 0;

  const guard = (fn: () => void) => {
    if (!accessToken) return router.push("/login");
    fn();
  };

  return (
    <div className="group card relative flex flex-col overflow-hidden transition-shadow hover:shadow-lg">
      {discount > 0 && <Badge variant="danger" className="absolute left-3 top-3 z-10">-{discount}%</Badge>}

      <div className="absolute right-3 top-3 z-10 flex flex-col gap-2 opacity-0 transition-opacity group-hover:opacity-100">
        <button
          onClick={() => guard(() => addToWishlist.mutate(product.id))}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-white/90 shadow hover:bg-white dark:bg-ink-800/90"
          aria-label="Add to wishlist"
        >
          <Heart size={15} />
        </button>
        <button
          onClick={() => guard(() => addToCompare.mutate(product.id))}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-white/90 shadow hover:bg-white dark:bg-ink-800/90"
          aria-label="Add to compare"
        >
          <GitCompareArrows size={15} />
        </button>
      </div>

      <Link href={`/products/${product.slug}`} className="relative block aspect-square overflow-hidden bg-ink-50 dark:bg-ink-800">
        <Image
          src={product.thumbnail}
          alt={product.title}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {product.stock === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <Badge variant="danger">Out of stock</Badge>
          </div>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-1.5 p-4">
        {product.brand && <span className="text-xs font-medium uppercase tracking-wide text-ink-400">{product.brand.name}</span>}
        <Link href={`/products/${product.slug}`} className="line-clamp-2 text-sm font-semibold hover:text-brand-600">
          {product.title}
        </Link>
        <Rating value={product.avgRating} count={product.reviewCount} size={13} />
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-lg font-bold">{formatCurrency(product.price)}</span>
          {product.compareAtPrice && (
            <span className="text-sm text-ink-400 line-through">{formatCurrency(product.compareAtPrice)}</span>
          )}
        </div>
        <button
          onClick={() => guard(() => addToCart.mutate({ productId: product.id, quantity: 1 }))}
          disabled={product.stock === 0}
          className={cn(
            "btn-primary mt-2 w-full text-xs disabled:cursor-not-allowed",
          )}
        >
          <ShoppingCart size={14} /> Add to Cart
        </button>
      </div>
    </div>
  );
}

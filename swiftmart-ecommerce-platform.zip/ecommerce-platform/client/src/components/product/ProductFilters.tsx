"use client";

import { useCategories, useBrands } from "@/hooks/useProducts";

interface Props {
  filters: any;
  onChange: (patch: any) => void;
}

export function ProductFilters({ filters, onChange }: Props) {
  const { data: categories } = useCategories();
  const { data: brands } = useBrands();

  return (
    <aside className="w-full shrink-0 space-y-6 lg:w-64">
      <div>
        <h4 className="mb-3 text-sm font-semibold">Category</h4>
        <div className="space-y-1.5">
          <button
            onClick={() => onChange({ category: undefined })}
            className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-sm ${!filters.category ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20" : "hover:bg-ink-50 dark:hover:bg-ink-800"}`}
          >
            All Categories
          </button>
          {categories?.map((c: any) => (
            <button
              key={c.id}
              onClick={() => onChange({ category: c.slug })}
              className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-sm ${filters.category === c.slug ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20" : "hover:bg-ink-50 dark:hover:bg-ink-800"}`}
            >
              {c.name} <span className="text-ink-400">({c._count?.products ?? 0})</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="mb-3 text-sm font-semibold">Brand</h4>
        <div className="space-y-1.5">
          <button
            onClick={() => onChange({ brand: undefined })}
            className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-sm ${!filters.brand ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20" : "hover:bg-ink-50 dark:hover:bg-ink-800"}`}
          >
            All Brands
          </button>
          {brands?.map((b: any) => (
            <button
              key={b.id}
              onClick={() => onChange({ brand: b.slug })}
              className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-sm ${filters.brand === b.slug ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20" : "hover:bg-ink-50 dark:hover:bg-ink-800"}`}
            >
              {b.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="mb-3 text-sm font-semibold">Price Range</h4>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="Min"
            className="input py-1.5 text-sm"
            defaultValue={filters.minPrice}
            onBlur={(e) => onChange({ minPrice: e.target.value ? Number(e.target.value) : undefined })}
          />
          <span className="text-ink-400">–</span>
          <input
            type="number"
            placeholder="Max"
            className="input py-1.5 text-sm"
            defaultValue={filters.maxPrice}
            onBlur={(e) => onChange({ maxPrice: e.target.value ? Number(e.target.value) : undefined })}
          />
        </div>
      </div>

      <div>
        <h4 className="mb-3 text-sm font-semibold">Minimum Rating</h4>
        <div className="flex gap-2">
          {[4, 3, 2, 1].map((r) => (
            <button
              key={r}
              onClick={() => onChange({ rating: filters.rating === r ? undefined : r })}
              className={`rounded-lg border px-2.5 py-1 text-xs ${filters.rating === r ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-900/20" : "border-ink-200 dark:border-ink-700"}`}
            >
              {r}+ ★
            </button>
          ))}
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={!!filters.inStock}
          onChange={(e) => onChange({ inStock: e.target.checked || undefined })}
          className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500"
        />
        In stock only
      </label>
    </aside>
  );
}

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function Rating({ value, count, size = 16 }: { value: number; count?: number; size?: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={size}
            className={cn(
              i < Math.round(value) ? "fill-brand-500 text-brand-500" : "fill-ink-200 text-ink-200 dark:fill-ink-700 dark:text-ink-700"
            )}
          />
        ))}
      </div>
      {count !== undefined && <span className="text-xs text-ink-500">({count.toLocaleString()})</span>}
    </div>
  );
}

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import toast from "react-hot-toast";

export function useAdminProducts(page = 1, search = "") {
  return useQuery({
    queryKey: ["admin", "products", page, search],
    queryFn: async () => (await api.get("/products", { params: { page, limit: 20, search } })).data,
  });
}

export function useCreateProduct() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: any) => api.post("/products", payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "products"] }); toast.success("Product created"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useUpdateProduct() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: any }) => api.patch(`/products/${id}`, payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "products"] }); toast.success("Product updated"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useDeleteProduct() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.delete(`/products/${id}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "products"] }); toast.success("Product removed"); },
  });
}

export function useAdminAllOrders(page = 1, status?: string) {
  return useQuery({
    queryKey: ["admin", "orders", page, status],
    queryFn: async () => (await api.get("/orders/admin/all", { params: { page, limit: 20, status } })).data,
  });
}

export function useUpdateOrderStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...payload }: { id: string; status: string; message: string; location?: string }) =>
      api.patch(`/orders/${id}/status`, payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "orders"] }); toast.success("Order status updated"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useVerifyBankTransfer() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (orderId: string) => api.patch(`/orders/${orderId}/bank-transfer/verify`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "orders"] }); toast.success("Bank transfer verified — order marked as paid"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useAdminCoupons() {
  return useQuery({ queryKey: ["admin", "coupons"], queryFn: async () => (await api.get("/coupons")).data.data });
}

export function useCreateCoupon() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: any) => api.post("/coupons", payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "coupons"] }); toast.success("Coupon created"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useDeactivateCoupon() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.patch(`/coupons/${id}/deactivate`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "coupons"] }); toast.success("Coupon deactivated"); },
  });
}

import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export function useDashboardSummary() {
  return useQuery({ queryKey: ["admin", "summary"], queryFn: async () => (await api.get("/analytics/summary")).data.data });
}
export function useRevenueSeries(days = 30) {
  return useQuery({ queryKey: ["admin", "revenue", days], queryFn: async () => (await api.get("/analytics/revenue", { params: { days } })).data.data });
}
export function useTopProducts() {
  return useQuery({ queryKey: ["admin", "top-products"], queryFn: async () => (await api.get("/analytics/top-products")).data.data });
}
export function useOrdersByStatus() {
  return useQuery({ queryKey: ["admin", "orders-by-status"], queryFn: async () => (await api.get("/analytics/orders-by-status")).data.data });
}

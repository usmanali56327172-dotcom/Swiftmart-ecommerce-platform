import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import { useAuthStore } from "@/store/auth.store";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

export function useCurrentUser() {
  const { accessToken, setUser, isHydrated } = useAuthStore();
  return useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const { data } = await api.get("/auth/me");
      setUser(data.data);
      return data.data;
    },
    enabled: !!accessToken && isHydrated,
    retry: false,
    staleTime: 5 * 60 * 1000,
  });
}

export function useLogin() {
  const setAccessToken = useAuthStore((s) => s.setAccessToken);
  const setUser = useAuthStore((s) => s.setUser);
  const router = useRouter();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { email: string; password: string }) => {
      const { data } = await api.post("/auth/login", payload);
      return data.data;
    },
    onSuccess: (data) => {
      setAccessToken(data.accessToken);
      setUser(data.user);
      qc.invalidateQueries();
      toast.success("Welcome back!");
      router.push(data.user.role === "ADMIN" ? "/admin" : "/account");
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useRegister() {
  const setAccessToken = useAuthStore((s) => s.setAccessToken);
  const router = useRouter();

  return useMutation({
    mutationFn: async (payload: { name: string; email: string; password: string }) => {
      const { data } = await api.post("/auth/register", payload);
      return data.data;
    },
    onSuccess: (data) => {
      setAccessToken(data.accessToken);
      toast.success("Account created! Welcome to SwiftMart.");
      router.push("/account");
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useLogout() {
  const logout = useAuthStore((s) => s.logout);
  const router = useRouter();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: () => api.post("/auth/logout"),
    onSuccess: () => {
      logout();
      qc.clear();
      router.push("/");
    },
  });
}

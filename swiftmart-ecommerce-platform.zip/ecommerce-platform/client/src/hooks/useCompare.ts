import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import { useAuthStore } from "@/store/auth.store";
import toast from "react-hot-toast";

export function useCompareList() {
  const accessToken = useAuthStore((s) => s.accessToken);
  return useQuery({
    queryKey: ["compare"],
    queryFn: async () => (await api.get("/compare")).data.data,
    enabled: !!accessToken,
  });
}

export function useToggleCompare() {
  const qc = useQueryClient();
  const add = useMutation({
    mutationFn: (productId: string) => api.post("/compare/items", { productId }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["compare"] }),
    onError: (err) => toast.error(getErrorMessage(err)),
  });
  const remove = useMutation({
    mutationFn: (productId: string) => api.delete(`/compare/items/${productId}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["compare"] }),
  });
  return { add, remove };
}

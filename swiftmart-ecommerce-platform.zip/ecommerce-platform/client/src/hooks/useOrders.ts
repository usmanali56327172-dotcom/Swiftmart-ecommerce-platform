import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import toast from "react-hot-toast";

export function useMyOrders(page = 1) {
  return useQuery({
    queryKey: ["orders", "my", page],
    queryFn: async () => (await api.get("/orders/my", { params: { page, limit: 10 } })).data,
  });
}

export function useOrder(id: string) {
  return useQuery({
    queryKey: ["order", id],
    queryFn: async () => (await api.get(`/orders/${id}`)).data.data,
    enabled: !!id,
  });
}

export type CheckoutPaymentMethod = "card" | "jazzcash" | "bank_transfer" | "cod";

export function useCreateOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: {
      addressId: string;
      paymentMethod: CheckoutPaymentMethod;
      jazzCashMobileNumber?: string;
      jazzCashCnic?: string;
    }) => api.post("/orders", payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["cart"] });
      qc.invalidateQueries({ queryKey: ["orders"] });
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useSubmitBankTransferReference() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ orderId, reference }: { orderId: string; reference: string }) =>
      api.post(`/orders/${orderId}/bank-transfer/reference`, { reference }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["order"] });
      toast.success("Reference submitted — we'll verify it shortly");
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

export function useAddresses() {
  return useQuery({
    queryKey: ["addresses"],
    queryFn: async () => (await api.get("/addresses")).data.data,
  });
}

export function useCreateAddress() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: any) => api.post("/addresses", payload),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["addresses"] }); toast.success("Address saved"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

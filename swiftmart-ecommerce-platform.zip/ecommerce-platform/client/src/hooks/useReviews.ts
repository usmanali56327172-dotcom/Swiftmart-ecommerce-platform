import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import toast from "react-hot-toast";

export function useProductReviews(productId: string) {
  return useQuery({
    queryKey: ["reviews", productId],
    queryFn: async () => (await api.get(`/reviews/product/${productId}`)).data.data,
    enabled: !!productId,
  });
}

export function useCreateReview(productId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: { rating: number; comment: string; title?: string }) =>
      api.post(`/reviews/product/${productId}`, payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reviews", productId] });
      qc.invalidateQueries({ queryKey: ["product"] });
      toast.success("Review submitted — thank you!");
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

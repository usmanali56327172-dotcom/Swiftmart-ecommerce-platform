import { useMutation } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import toast from "react-hot-toast";

/** Uploads one or more image files and returns their public URLs. */
export function useUploadImages() {
  return useMutation({
    mutationFn: async (files: File[]) => {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f));
      const { data } = await api.post("/uploads/images", formData);
      return data.data.urls as string[];
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
}

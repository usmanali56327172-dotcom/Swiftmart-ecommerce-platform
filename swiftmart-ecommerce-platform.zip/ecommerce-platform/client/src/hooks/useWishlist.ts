import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, getErrorMessage } from "@/lib/api";
import { useAuthStore } from "@/store/auth.store";
import toast from "react-hot-toast";

export function useWishlist() {
  const accessToken = useAuthStore((s) => s.accessToken);
  return useQuery({
    queryKey: ["wishlist"],
    queryFn: async () => (await api.get("/wishlist")).data.data,
    enabled: !!accessToken,
  });
}

export function useToggleWishlist() {
  const qc = useQueryClient();
  const add = useMutation({
    mutationFn: (productId: string) => api.post("/wishlist/items", { productId }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wishlist"] }); toast.success("Added to wishlist"); },
    onError: (err) => toast.error(getErrorMessage(err)),
  });
  const remove = useMutation({
    mutationFn: (productId: string) => api.delete(`/wishlist/items/${productId}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wishlist"] }); toast.success("Removed from wishlist"); },
  });
  return { add, remove };
}

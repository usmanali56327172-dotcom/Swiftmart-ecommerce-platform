import { create } from "zustand";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: "CUSTOMER" | "ADMIN";
}

interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  isHydrated: boolean;
  setUser: (user: AuthUser | null) => void;
  setAccessToken: (token: string | null) => void;
  setHydrated: (v: boolean) => void;
  logout: () => void;
}

/**
 * Access token lives only in memory (never localStorage) to reduce XSS blast radius.
 * The refresh token lives in an httpOnly cookie set by the API and is never touched by JS.
 */
export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  accessToken: null,
  isHydrated: false,
  setUser: (user) => set({ user }),
  setAccessToken: (accessToken) => set({ accessToken }),
  setHydrated: (isHydrated) => set({ isHydrated }),
  logout: () => set({ user: null, accessToken: null }),
}));

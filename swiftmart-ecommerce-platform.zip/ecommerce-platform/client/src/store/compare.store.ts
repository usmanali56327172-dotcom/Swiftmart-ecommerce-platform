import { create } from "zustand";

interface CompareUiState {
  isBarOpen: boolean;
  setBarOpen: (v: boolean) => void;
}

export const useCompareUiStore = create<CompareUiState>((set) => ({
  isBarOpen: false,
  setBarOpen: (isBarOpen) => set({ isBarOpen }),
}));

#!/usr/bin/env bash
# ============================================================
# deploy.sh — single-VPS deploy for the SwiftMart stack.
#
# What it does, in order:
#   1. Loads ./.env (DOMAIN, DB creds, JWT secrets, Stripe/JazzCash/bank vars)
#   2. Builds and starts postgres, server, client
#   3. Renders the HTTP-only Nginx config and starts Nginx so port 80 is live
#   4. Requests a Let's Encrypt certificate for DOMAIN via certbot (webroot mode)
#   5. Renders the final HTTPS Nginx config and reloads Nginx
#   6. Starts the certbot renewal container (checks twice daily, renews near expiry)
#
# Safe to re-run: if a certificate already exists for DOMAIN, steps 3–5 are
# skipped and it just rebuilds/restarts the app containers.
#
# Usage:
#   cp .env.example .env   # fill in real values first
#   chmod +x deploy.sh
#   ./deploy.sh
# ============================================================
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "Missing .env — copy .env.example to .env and fill in real values first." >&2
  exit 1
fi
set -a
source .env
set +a

if [ -z "${DOMAIN:-}" ] || [ "$DOMAIN" = "shop.example.com" ]; then
  echo "Set a real DOMAIN in .env before deploying." >&2
  exit 1
fi

COMPOSE="docker compose -f docker-compose.prod.yml"
CERT_PATH="./certbot/conf/live/${DOMAIN}/fullchain.pem"

mkdir -p nginx/conf.d certbot/conf certbot/www

echo "==> Building and starting the application containers..."
$COMPOSE up -d --build postgres server client

if [ -f "$CERT_PATH" ]; then
  echo "==> Certificate for ${DOMAIN} already exists — rendering the SSL config and (re)starting Nginx."
  DOMAIN="$DOMAIN" envsubst '${DOMAIN}' < nginx/templates/ssl.conf.template > nginx/conf.d/app.conf
  $COMPOSE up -d --force-recreate nginx
  $COMPOSE up -d certbot
  echo "==> Done. https://${DOMAIN} should be live."
  exit 0
fi

echo "==> No certificate found yet — bootstrapping over plain HTTP first."
DOMAIN="$DOMAIN" envsubst '${DOMAIN}' < nginx/templates/http-bootstrap.conf.template > nginx/conf.d/app.conf
$COMPOSE up -d nginx

echo "==> Waiting for Nginx to be reachable on port 80..."
sleep 5

echo "==> Requesting a Let's Encrypt certificate for ${DOMAIN} (and www.${DOMAIN})..."
docker run --rm \
  -v "$(pwd)/certbot/conf:/etc/letsencrypt" \
  -v "$(pwd)/certbot/www:/var/www/certbot" \
  certbot/certbot certonly --webroot -w /var/www/certbot \
  -d "$DOMAIN" -d "www.$DOMAIN" \
  --email "${LETSENCRYPT_EMAIL:-admin@$DOMAIN}" --agree-tos --non-interactive --no-eff-email

if [ ! -f "$CERT_PATH" ]; then
  echo "Certificate issuance failed — check that DNS for ${DOMAIN} points at this server's IP and that ports 80/443 are open, then re-run this script." >&2
  exit 1
fi

echo "==> Certificate issued. Switching Nginx to the HTTPS config..."
DOMAIN="$DOMAIN" envsubst '${DOMAIN}' < nginx/templates/ssl.conf.template > nginx/conf.d/app.conf
$COMPOSE restart nginx
$COMPOSE up -d certbot

echo "==> Done. https://${DOMAIN} is live, and certificates will auto-renew."

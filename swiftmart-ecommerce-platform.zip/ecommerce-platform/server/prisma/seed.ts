import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  const passwordHash = await bcrypt.hash("Password1", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@swiftmart.com" },
    update: {},
    create: {
      name: "Admin User",
      email: "admin@swiftmart.com",
      passwordHash,
      role: "ADMIN",
      cart: { create: {} },
      wishlist: { create: {} },
    },
  });

  const customer = await prisma.user.upsert({
    where: { email: "customer@swiftmart.com" },
    update: {},
    create: {
      name: "Jane Doe",
      email: "customer@swiftmart.com",
      passwordHash,
      role: "CUSTOMER",
      cart: { create: {} },
      wishlist: { create: {} },
    },
  });

  const categoriesData = [
    { name: "Electronics", slug: "electronics", description: "Phones, laptops, audio, and gadgets" },
    { name: "Fashion", slug: "fashion", description: "Clothing, footwear, and accessories" },
    { name: "Home & Kitchen", slug: "home-kitchen", description: "Furniture, decor, and appliances" },
    { name: "Sports & Outdoors", slug: "sports-outdoors", description: "Fitness, camping, and outdoor gear" },
    { name: "Beauty & Personal Care", slug: "beauty-personal-care", description: "Skincare, makeup, and grooming" },
  ];
  const categories = [];
  for (const c of categoriesData) {
    categories.push(await prisma.category.upsert({ where: { slug: c.slug }, update: {}, create: c }));
  }

  const brandsData = [
    { name: "Apex", slug: "apex" },
    { name: "Nova", slug: "nova" },
    { name: "Vertex", slug: "vertex" },
    { name: "Lumen", slug: "lumen" },
    { name: "Strata", slug: "strata" },
  ];
  const brands = [];
  for (const b of brandsData) {
    brands.push(await prisma.brand.upsert({ where: { slug: b.slug }, update: {}, create: b }));
  }

  const productTemplates = [
    { title: "Wireless Noise-Cancelling Headphones", price: 24999, compareAtPrice: 31999, cat: 0 },
    { title: "4K Ultra HD Smart TV 55-inch", price: 89999, compareAtPrice: 109999, cat: 0 },
    { title: "Mechanical Gaming Keyboard", price: 12999, compareAtPrice: 15999, cat: 0 },
    { title: "Ergonomic Office Chair", price: 32999, compareAtPrice: 39999, cat: 2 },
    { title: "Non-Stick Cookware Set (10-Piece)", price: 18999, compareAtPrice: 23999, cat: 2 },
    { title: "Men's Running Shoes", price: 8999, compareAtPrice: 11999, cat: 1 },
    { title: "Women's Denim Jacket", price: 6999, compareAtPrice: 8999, cat: 1 },
    { title: "Adjustable Dumbbell Set", price: 27999, compareAtPrice: 33999, cat: 3 },
    { title: "Camping Tent (4-Person)", price: 19999, compareAtPrice: 24999, cat: 3 },
    { title: "Vitamin C Serum", price: 2499, compareAtPrice: 3299, cat: 4 },
    { title: "Electric Toothbrush", price: 5999, compareAtPrice: 7999, cat: 4 },
    { title: "Bluetooth Portable Speaker", price: 8999, compareAtPrice: 11999, cat: 0 },
    { title: "Stainless Steel Water Bottle", price: 1999, compareAtPrice: 2599, cat: 3 },
    { title: "Leather Crossbody Bag", price: 10999, compareAtPrice: 14999, cat: 1 },
    { title: "Smart Fitness Watch", price: 16999, compareAtPrice: 20999, cat: 0 },
    { title: "LED Desk Lamp with USB Charging", price: 3499, compareAtPrice: 4499, cat: 2 },
  ];

  const images = [
    "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
    "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f",
  ];

  for (let i = 0; i < productTemplates.length; i++) {
    const t = productTemplates[i];
    const slug = t.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + i;
    const product = await prisma.product.upsert({
      where: { slug },
      update: {},
      create: {
        title: t.title,
        slug,
        description: `${t.title} — premium quality, built to last, backed by our 30-day satisfaction guarantee. Perfect for everyday use with a sleek, modern design.`,
        price: t.price,
        compareAtPrice: t.compareAtPrice,
        costPrice: t.price * 0.6,
        sku: `SKU-${1000 + i}`,
        stock: 20 + ((i * 7) % 50),
        lowStockThreshold: 5,
        images,
        thumbnail: images[0],
        categoryId: categories[t.cat].id,
        brandId: brands[i % brands.length].id,
        tags: [t.title.split(" ")[0].toLowerCase()],
        isFeatured: i % 4 === 0,
        attributes: { color: ["Black", "White", "Blue"][i % 3] },
      },
    });

    await prisma.inventoryLog.create({
      data: { productId: product.id, change: product.stock, reason: "RESTOCK", note: "Seed data" },
    });
  }

  await prisma.coupon.upsert({
    where: { code: "WELCOME10" },
    update: {},
    create: {
      code: "WELCOME10",
      type: "PERCENTAGE",
      value: 10,
      minOrderAmount: 3000,
      maxDiscount: 5000,
      usageLimit: 1000,
      isActive: true,
    },
  });

  await prisma.coupon.upsert({
    where: { code: "SAVE20" },
    update: {},
    create: {
      code: "SAVE20",
      type: "FIXED",
      value: 2000,
      minOrderAmount: 10000,
      usageLimit: 500,
      isActive: true,
    },
  });

  console.log("Seed complete.");
  console.log(`Admin login:    admin@swiftmart.com / Password1`);
  console.log(`Customer login: customer@swiftmart.com / Password1`);
  void admin;
  void customer;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

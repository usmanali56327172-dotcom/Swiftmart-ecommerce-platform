import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import swaggerUi from "swagger-ui-express";

import { env } from "./config/env";
import { swaggerSpec } from "./config/swagger";
import { apiLimiter } from "./middleware/rateLimit";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { stripeWebhook, jazzCashCallback } from "./controllers/payment.controller";
import routes from "./routes";

export const app = express();

app.use(helmet());
app.use(
  cors({
    origin: env.CLIENT_URL,
    credentials: true,
  })
);
app.use(compression());
app.use(morgan(env.isProd ? "combined" : "dev"));

// Stripe requires the raw request body to verify webhook signatures,
// so this route is registered BEFORE the JSON body parser.
app.post("/api/v1/payments/webhook", express.raw({ type: "application/json" }), stripeWebhook);

// JazzCash posts the transaction result as application/x-www-form-urlencoded.
app.post("/api/v1/payments/jazzcash/callback", express.urlencoded({ extended: true }), jazzCashCallback);

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use("/api/v1", apiLimiter);

app.get("/health", (_req, res) => res.json({ status: "ok", timestamp: new Date().toISOString() }));
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use("/api/v1", routes);

app.use(notFoundHandler);
app.use(errorHandler);

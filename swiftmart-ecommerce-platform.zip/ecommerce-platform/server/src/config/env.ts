import dotenv from "dotenv";
dotenv.config();

function required(key: string, fallback?: string): string {
  const value = process.env[key] ?? fallback;
  if (value === undefined) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  PORT: Number(process.env.PORT ?? 5000),
  CLIENT_URL: required("CLIENT_URL", "http://localhost:3000"),
  // Used to build absolute URLs for locally-uploaded files (e.g. http://localhost:5000).
  // Set this to your real API domain in production.
  API_PUBLIC_URL: process.env.API_PUBLIC_URL ?? `http://localhost:${process.env.PORT ?? 5000}`,
  DATABASE_URL: required("DATABASE_URL"),
  JWT_ACCESS_SECRET: required("JWT_ACCESS_SECRET"),
  JWT_REFRESH_SECRET: required("JWT_REFRESH_SECRET"),
  JWT_ACCESS_EXPIRES_IN: process.env.JWT_ACCESS_EXPIRES_IN ?? "15m",
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN ?? "30d",
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY ?? "",
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET ?? "",
  RATE_LIMIT_WINDOW_MS: Number(process.env.RATE_LIMIT_WINDOW_MS ?? 900000),
  RATE_LIMIT_MAX: Number(process.env.RATE_LIMIT_MAX ?? 300),

  // JazzCash Mobile Wallet (Pakistan) — sandbox by default.
  // Real credentials come from JazzCash's merchant onboarding portal.
  JAZZCASH_MERCHANT_ID: process.env.JAZZCASH_MERCHANT_ID ?? "MC00000",
  JAZZCASH_PASSWORD: process.env.JAZZCASH_PASSWORD ?? "sandbox_password",
  JAZZCASH_INTEGRITY_SALT: process.env.JAZZCASH_INTEGRITY_SALT ?? "sandbox_salt",
  JAZZCASH_API_BASE:
    process.env.JAZZCASH_API_BASE ?? "https://sandbox.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction",
  JAZZCASH_RETURN_URL: process.env.JAZZCASH_RETURN_URL ?? "http://localhost:3000/checkout",

  // Bank transfer — the account details shown to customers at checkout.
  BANK_NAME: process.env.BANK_NAME ?? "Meezan Bank",
  BANK_ACCOUNT_TITLE: process.env.BANK_ACCOUNT_TITLE ?? "SwiftMart Retail (Pvt) Ltd",
  BANK_ACCOUNT_NUMBER: process.env.BANK_ACCOUNT_NUMBER ?? "PK00 MEZN 0000 0123 4567 8901",
  BANK_IBAN: process.env.BANK_IBAN ?? "PK00MEZN0000012345678901",

  isProd: process.env.NODE_ENV === "production",
};

import fs from "fs";
import path from "path";
import yaml from "js-yaml";

const openapiPath = path.join(__dirname, "../../docs/openapi.yaml");
export const swaggerSpec = yaml.load(fs.readFileSync(openapiPath, "utf8"));

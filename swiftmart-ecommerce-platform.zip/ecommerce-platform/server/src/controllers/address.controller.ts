import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

export const listAddresses = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await prisma.address.findMany({ where: { userId: req.user!.id }, orderBy: { isDefault: "desc" } }));
});

export const createAddress = asyncHandler(async (req: Request, res: Response) => {
  const userId = req.user!.id;
  if (req.body.isDefault) {
    await prisma.address.updateMany({ where: { userId }, data: { isDefault: false } });
  }
  const address = await prisma.address.create({ data: { ...req.body, userId } });
  sendSuccess(res, address, "Address added", 201);
});

export const updateAddress = asyncHandler(async (req: Request, res: Response) => {
  const existing = await prisma.address.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!existing) throw ApiError.notFound("Address not found");
  if (req.body.isDefault) {
    await prisma.address.updateMany({ where: { userId: req.user!.id }, data: { isDefault: false } });
  }
  sendSuccess(res, await prisma.address.update({ where: { id: req.params.id }, data: req.body }), "Address updated");
});

export const deleteAddress = asyncHandler(async (req: Request, res: Response) => {
  const existing = await prisma.address.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
  if (!existing) throw ApiError.notFound("Address not found");
  await prisma.address.delete({ where: { id: req.params.id } });
  sendSuccess(res, null, "Address deleted");
});

import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { AnalyticsService } from "../services/analytics.service";

export const getDashboardSummary = asyncHandler(async (_req: Request, res: Response) => {
  sendSuccess(res, await AnalyticsService.dashboardSummary());
});
export const getRevenueSeries = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await AnalyticsService.revenueSeries(Number(req.query.days ?? 30)));
});
export const getTopProducts = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await AnalyticsService.topProducts(Number(req.query.limit ?? 10)));
});
export const getOrdersByStatus = asyncHandler(async (_req: Request, res: Response) => {
  sendSuccess(res, await AnalyticsService.ordersByStatus());
});

import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { AuthService } from "../services/auth.service";
import { env } from "../config/env";

const REFRESH_COOKIE_OPTS = {
  httpOnly: true,
  secure: env.isProd,
  sameSite: "lax" as const,
  path: "/api/v1/auth/refresh",
  maxAge: 30 * 24 * 60 * 60 * 1000,
};

export const register = asyncHandler(async (req: Request, res: Response) => {
  const { name, email, password } = req.body;
  const { accessToken, refreshToken } = await AuthService.register(name, email, password);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { accessToken }, "Account created successfully", 201);
});

export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  const { accessToken, refreshToken, user } = await AuthService.login(email, password);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { accessToken, user: { id: user.id, name: user.name, email: user.email, role: user.role } }, "Logged in successfully");
});

export const refresh = asyncHandler(async (req: Request, res: Response) => {
  const token = req.cookies?.refreshToken;
  const { accessToken, refreshToken } = await AuthService.refresh(token);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { accessToken }, "Token refreshed");
});

export const logout = asyncHandler(async (req: Request, res: Response) => {
  const token = req.cookies?.refreshToken;
  if (token) await AuthService.logout(token);
  res.clearCookie("refreshToken", { path: "/api/v1/auth/refresh" });
  sendSuccess(res, null, "Logged out successfully");
});

export const me = asyncHandler(async (req: Request, res: Response) => {
  const user = await AuthService.me(req.user!.id);
  sendSuccess(res, user);
});

export const changePassword = asyncHandler(async (req: Request, res: Response) => {
  await AuthService.changePassword(req.user!.id, req.body.currentPassword, req.body.newPassword);
  sendSuccess(res, null, "Password updated successfully");
});

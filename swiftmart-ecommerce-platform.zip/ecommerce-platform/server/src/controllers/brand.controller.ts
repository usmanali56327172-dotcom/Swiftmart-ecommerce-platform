import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { prisma } from "../config/prisma";
import { ProductService } from "../services/product.service";

export const listBrands = asyncHandler(async (_req: Request, res: Response) => {
  const brands = await prisma.brand.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: "asc" },
  });
  sendSuccess(res, brands);
});

export const createBrand = asyncHandler(async (req: Request, res: Response) => {
  const { name, logoUrl } = req.body;
  const slug = ProductService.slugify(name);
  const brand = await prisma.brand.create({ data: { name, slug, logoUrl } });
  sendSuccess(res, brand, "Brand created", 201);
});

export const updateBrand = asyncHandler(async (req: Request, res: Response) => {
  const brand = await prisma.brand.update({ where: { id: req.params.id }, data: req.body });
  sendSuccess(res, brand, "Brand updated");
});

export const deleteBrand = asyncHandler(async (req: Request, res: Response) => {
  await prisma.brand.delete({ where: { id: req.params.id } });
  sendSuccess(res, null, "Brand deleted");
});

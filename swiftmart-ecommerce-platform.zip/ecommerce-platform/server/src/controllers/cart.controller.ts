import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { CartService } from "../services/cart.service";

const withTotals = (cart: any) => ({ ...cart, totals: CartService.calculateTotals(cart) });

export const getCart = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CartService.getOrCreate(req.user!.id);
  sendSuccess(res, withTotals(cart));
});

export const addToCart = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CartService.addItem(req.user!.id, req.body.productId, req.body.quantity ?? 1);
  sendSuccess(res, withTotals(cart), "Item added to cart");
});

export const updateCartItem = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CartService.updateItem(req.user!.id, req.params.productId, req.body.quantity);
  sendSuccess(res, withTotals(cart), "Cart updated");
});

export const removeCartItem = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CartService.removeItem(req.user!.id, req.params.productId);
  sendSuccess(res, withTotals(cart), "Item removed from cart");
});

export const clearCart = asyncHandler(async (req: Request, res: Response) => {
  await CartService.clear(req.user!.id);
  sendSuccess(res, null, "Cart cleared");
});

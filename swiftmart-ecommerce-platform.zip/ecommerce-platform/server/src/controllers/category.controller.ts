import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { prisma } from "../config/prisma";
import { ProductService } from "../services/product.service";
import { ApiError } from "../utils/ApiError";

export const listCategories = asyncHandler(async (_req: Request, res: Response) => {
  const categories = await prisma.category.findMany({
    include: { children: true, _count: { select: { products: true } } },
    where: { parentId: null },
    orderBy: { name: "asc" },
  });
  sendSuccess(res, categories);
});

export const createCategory = asyncHandler(async (req: Request, res: Response) => {
  const { name, description, imageUrl, parentId } = req.body;
  const slug = ProductService.slugify(name);
  const category = await prisma.category.create({ data: { name, slug, description, imageUrl, parentId } });
  sendSuccess(res, category, "Category created", 201);
});

export const updateCategory = asyncHandler(async (req: Request, res: Response) => {
  const category = await prisma.category.update({ where: { id: req.params.id }, data: req.body });
  sendSuccess(res, category, "Category updated");
});

export const deleteCategory = asyncHandler(async (req: Request, res: Response) => {
  const count = await prisma.product.count({ where: { categoryId: req.params.id } });
  if (count > 0) throw ApiError.conflict("Cannot delete a category that still has products");
  await prisma.category.delete({ where: { id: req.params.id } });
  sendSuccess(res, null, "Category deleted");
});

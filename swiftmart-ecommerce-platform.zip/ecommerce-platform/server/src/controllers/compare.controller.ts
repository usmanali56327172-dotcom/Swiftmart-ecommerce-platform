import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { CompareService } from "../services/compare.service";

export const getCompareList = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await CompareService.list(req.user!.id));
});
export const addToCompare = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await CompareService.add(req.user!.id, req.body.productId), "Added to comparison");
});
export const removeFromCompare = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await CompareService.remove(req.user!.id, req.params.productId), "Removed from comparison");
});

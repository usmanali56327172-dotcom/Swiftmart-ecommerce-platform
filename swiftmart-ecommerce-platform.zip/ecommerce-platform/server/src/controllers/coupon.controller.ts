import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { CouponService } from "../services/coupon.service";
import { CartService } from "../services/cart.service";

const withTotals = (cart: any) => ({ ...cart, totals: CartService.calculateTotals(cart) });

export const applyCoupon = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CouponService.apply(req.user!.id, req.body.code);
  sendSuccess(res, withTotals(cart), "Coupon applied");
});

export const removeCoupon = asyncHandler(async (req: Request, res: Response) => {
  const cart = await CouponService.remove(req.user!.id);
  sendSuccess(res, withTotals(cart), "Coupon removed");
});

export const listCoupons = asyncHandler(async (_req: Request, res: Response) => {
  sendSuccess(res, await CouponService.listAll());
});

export const createCoupon = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await CouponService.create(req.body), "Coupon created", 201);
});

export const deactivateCoupon = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await CouponService.deactivate(req.params.id), "Coupon deactivated");
});

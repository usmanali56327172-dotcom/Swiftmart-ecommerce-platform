import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { OrderService } from "../services/order.service";
import { BankTransferService } from "../services/bank-transfer.service";

export const createOrder = asyncHandler(async (req: Request, res: Response) => {
  const { addressId, paymentMethod, jazzCashMobileNumber, jazzCashCnic } = req.body;
  const jazzCashDetails =
    paymentMethod === "jazzcash" ? { mobileNumber: jazzCashMobileNumber, cnic: jazzCashCnic } : undefined;
  const result = await OrderService.createFromCart(req.user!.id, addressId, paymentMethod, jazzCashDetails);
  sendSuccess(res, result, "Order placed successfully", 201);
});

export const listMyOrders = asyncHandler(async (req: Request, res: Response) => {
  const { page = "1", limit = "10" } = req.query;
  const result = await OrderService.listForUser(req.user!.id, Number(page), Number(limit));
  sendSuccess(res, result.items, "Orders fetched", 200, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getOrder = asyncHandler(async (req: Request, res: Response) => {
  const order = await OrderService.getById(req.user!.id, req.user!.role, req.params.id);
  sendSuccess(res, order);
});

export const updateOrderStatus = asyncHandler(async (req: Request, res: Response) => {
  const { status, message, location } = req.body;
  const order = await OrderService.updateStatus(req.params.id, status, message, location);
  sendSuccess(res, order, "Order status updated");
});

export const listAllOrders = asyncHandler(async (req: Request, res: Response) => {
  const { page = "1", limit = "20", status } = req.query;
  const result = await OrderService.listAllForAdmin(Number(page), Number(limit), status as any);
  sendSuccess(res, result.items, "Orders fetched", 200, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const submitBankTransferReference = asyncHandler(async (req: Request, res: Response) => {
  const order = await BankTransferService.submitReference(req.user!.id, req.params.id, req.body.reference);
  sendSuccess(res, order, "Thanks — we'll verify your transfer shortly");
});

export const verifyBankTransfer = asyncHandler(async (req: Request, res: Response) => {
  const order = await BankTransferService.verifyByAdmin(req.user!.id, req.params.id);
  sendSuccess(res, order, "Bank transfer verified — order marked as paid");
});

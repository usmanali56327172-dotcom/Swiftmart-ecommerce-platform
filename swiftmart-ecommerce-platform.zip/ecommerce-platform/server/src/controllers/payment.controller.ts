import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { PaymentService } from "../services/payment.service";
import { OrderService } from "../services/order.service";
import { JazzCashService } from "../services/jazzcash.service";
import { prisma } from "../config/prisma";
import { logger } from "../config/logger";
import { ApiError } from "../utils/ApiError";

/** Stripe webhook: source of truth for payment confirmation (never trust the client alone). */
export const stripeWebhook = asyncHandler(async (req: Request, res: Response) => {
  const signature = req.headers["stripe-signature"] as string;
  let event;
  try {
    event = PaymentService.constructWebhookEvent(req.body, signature);
  } catch (err) {
    logger.warn(`Stripe webhook signature verification failed: ${(err as Error).message}`);
    return res.status(400).send(`Webhook Error: ${(err as Error).message}`);
  }

  if (event.type === "payment_intent.succeeded") {
    const intent = event.data.object as any;
    const order = await prisma.order.findFirst({ where: { paymentIntentId: intent.id } });
    if (order) await OrderService.markPaid(order.id);
  }

  if (event.type === "payment_intent.payment_failed") {
    const intent = event.data.object as any;
    await prisma.order.updateMany({ where: { paymentIntentId: intent.id }, data: { paymentStatus: "FAILED" } });
  }

  res.json({ received: true });
});

export const getPaymentStatus = asyncHandler(async (req: Request, res: Response) => {
  const intent = await PaymentService.retrievePaymentIntent(req.params.intentId);
  sendSuccess(res, { status: intent.status });
});

/**
 * JazzCash posts the transaction result here as form-encoded fields, signed
 * with pp_SecureHash. We re-derive the hash and reject anything that doesn't
 * match before touching the order — this is what stops a forged "success"
 * callback from marking an unpaid order as paid.
 */
export const jazzCashCallback = asyncHandler(async (req: Request, res: Response) => {
  const payload = req.body as Record<string, string>;

  if (!JazzCashService.verifyCallback(payload)) {
    logger.warn("JazzCash callback rejected: secure hash mismatch");
    throw ApiError.unauthorized("Invalid JazzCash signature");
  }

  const orderId = await OrderService.markJazzCashResult(
    payload.pp_TxnRefNo,
    payload.pp_ResponseCode,
    payload.pp_ResponseMessage ?? "Unknown response"
  );

  // JazzCash expects a redirect back to the merchant site after processing.
  res.redirect(302, `${process.env.CLIENT_URL ?? "http://localhost:3000"}/account/orders/${orderId}`);
});

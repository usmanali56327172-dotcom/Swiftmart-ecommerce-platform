import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { ProductService } from "../services/product.service";

export const listProducts = asyncHandler(async (req: Request, res: Response) => {
  const q = req.query;
  const result = await ProductService.list({
    page: Number(q.page ?? 1),
    limit: Math.min(Number(q.limit ?? 20), 100),
    search: q.search as string | undefined,
    category: q.category as string | undefined,
    brand: q.brand as string | undefined,
    minPrice: q.minPrice ? Number(q.minPrice) : undefined,
    maxPrice: q.maxPrice ? Number(q.maxPrice) : undefined,
    rating: q.rating ? Number(q.rating) : undefined,
    sort: q.sort as any,
    inStock: q.inStock === "true",
  });
  sendSuccess(res, result.items, "Products fetched", 200, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductService.getBySlug(req.params.slug);
  const related = await ProductService.getRelated(product.id, product.categoryId);
  sendSuccess(res, { product, related });
});

export const createProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductService.create(req.body);
  sendSuccess(res, product, "Product created", 201);
});

export const updateProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductService.update(req.params.id, req.body);
  sendSuccess(res, product, "Product updated");
});

export const deleteProduct = asyncHandler(async (req: Request, res: Response) => {
  await ProductService.delete(req.params.id);
  sendSuccess(res, null, "Product deleted");
});

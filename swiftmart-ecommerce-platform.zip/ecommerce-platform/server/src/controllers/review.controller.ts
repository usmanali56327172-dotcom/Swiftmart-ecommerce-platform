import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { ReviewService } from "../services/review.service";
import { prisma } from "../config/prisma";

export const listReviewsForProduct = asyncHandler(async (req: Request, res: Response) => {
  const reviews = await prisma.review.findMany({
    where: { productId: req.params.productId },
    include: { user: { select: { id: true, name: true, avatarUrl: true } } },
    orderBy: { createdAt: "desc" },
  });
  sendSuccess(res, reviews);
});

export const createReview = asyncHandler(async (req: Request, res: Response) => {
  const { rating, comment, title } = req.body;
  const review = await ReviewService.create(req.user!.id, req.params.productId, rating, comment, title);
  sendSuccess(res, review, "Review submitted", 201);
});

export const updateReview = asyncHandler(async (req: Request, res: Response) => {
  const review = await ReviewService.update(req.user!.id, req.params.id, req.body.rating, req.body.comment, req.body.title);
  sendSuccess(res, review, "Review updated");
});

export const deleteReview = asyncHandler(async (req: Request, res: Response) => {
  await ReviewService.delete(req.user!.id, req.user!.role, req.params.id);
  sendSuccess(res, null, "Review deleted");
});

export const markReviewHelpful = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await ReviewService.markHelpful(req.params.id), "Marked as helpful");
});

import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { ApiError } from "../utils/ApiError";
import { env } from "../config/env";

/**
 * Returns a publicly-fetchable URL for an uploaded file. In this dev/demo setup,
 * files are served straight off local disk via express.static (see app.ts).
 * For production, swap the storage engine in utils/multer.ts for an S3/Cloudinary
 * adapter and return that provider's URL here instead — the rest of the app only
 * ever deals with a plain image URL string, so nothing else needs to change.
 */
export const uploadProductImage = asyncHandler(async (req: Request, res: Response) => {
  if (!req.file) throw ApiError.badRequest("No image file was provided");

  const publicUrl = `${env.API_PUBLIC_URL}/uploads/products/${req.file.filename}`;
  sendSuccess(res, { url: publicUrl, filename: req.file.filename, size: req.file.size }, "Image uploaded", 201);
});

export const uploadProductImages = asyncHandler(async (req: Request, res: Response) => {
  const files = (req.files as Express.Multer.File[]) ?? [];
  if (!files.length) throw ApiError.badRequest("No image files were provided");

  const urls = files.map((f) => `${env.API_PUBLIC_URL}/uploads/products/${f.filename}`);
  sendSuccess(res, { urls }, "Images uploaded", 201);
});

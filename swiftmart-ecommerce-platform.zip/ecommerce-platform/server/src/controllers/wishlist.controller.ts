import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";
import { WishlistService } from "../services/wishlist.service";

export const getWishlist = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await WishlistService.getOrCreate(req.user!.id));
});
export const addToWishlist = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await WishlistService.add(req.user!.id, req.body.productId), "Added to wishlist");
});
export const removeFromWishlist = asyncHandler(async (req: Request, res: Response) => {
  sendSuccess(res, await WishlistService.remove(req.user!.id, req.params.productId), "Removed from wishlist");
});

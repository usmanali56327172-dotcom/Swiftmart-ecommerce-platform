import { NextFunction, Request, Response } from "express";
import { ApiError } from "../utils/ApiError";
import { verifyAccessToken } from "../utils/jwt";

declare global {
  namespace Express {
    interface Request {
      user?: { id: string; role: "CUSTOMER" | "ADMIN" };
    }
  }
}

/** Requires a valid access token. Populates req.user. */
export const authenticate = (req: Request, _res: Response, next: NextFunction) => {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith("Bearer ")) throw ApiError.unauthorized("Missing access token");

    const token = header.split(" ")[1];
    const payload = verifyAccessToken(token);
    req.user = { id: payload.sub, role: payload.role };
    next();
  } catch {
    next(ApiError.unauthorized("Invalid or expired access token"));
  }
};

/** Restricts a route to one or more roles. Use after `authenticate`. */
export const authorize = (...roles: Array<"CUSTOMER" | "ADMIN">) => {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(ApiError.unauthorized());
    if (!roles.includes(req.user.role)) return next(ApiError.forbidden("Insufficient permissions"));
    next();
  };
};

/** Populates req.user if a valid token is present, but does not require one. */
export const optionalAuth = (req: Request, _res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  if (header?.startsWith("Bearer ")) {
    try {
      const payload = verifyAccessToken(header.split(" ")[1]);
      req.user = { id: payload.sub, role: payload.role };
    } catch {
      /* ignore invalid token for optional auth */
    }
  }
  next();
};

import multer from "multer";
import path from "path";
import fs from "fs";
import { customAlphabet } from "nanoid";
import { ApiError } from "../utils/ApiError";

const nanoid = customAlphabet("abcdefghijklmnopqrstuvwxyz0123456789", 12);

const UPLOAD_DIR = path.join(process.cwd(), "uploads", "products");
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const ALLOWED_MIME_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    cb(null, `${Date.now()}-${nanoid()}${ext}`);
  },
});

/**
 * Local-disk image upload for admin product photography.
 *
 * NOTE: this stores files on the API server's local filesystem, which is
 * fine for a single-instance dev/demo deployment but will NOT survive
 * container restarts or work across multiple horizontally-scaled instances
 * in production. For production, swap the multer storage engine below for
 * multer-s3 (or an equivalent Cloudinary/GCS adapter) — the rest of the
 * upload flow (route, validation, response shape) stays identical.
 */
export const uploadImage = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE },
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
      return cb(ApiError.badRequest("Only JPEG, PNG, WEBP, or GIF images are allowed") as unknown as Error);
    }
    cb(null, true);
  },
}).single("file");

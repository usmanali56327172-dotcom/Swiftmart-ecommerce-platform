import { NextFunction, Request, Response } from "express";
import { AnyZodObject, ZodError } from "zod";
import { ApiError } from "../utils/ApiError";

/** Validates req.body/query/params against a Zod schema shaped as { body, query, params }. */
export const validate = (schema: AnyZodObject) => (req: Request, _res: Response, next: NextFunction) => {
  try {
    schema.parse({ body: req.body, query: req.query, params: req.params });
    next();
  } catch (err) {
    if (err instanceof ZodError) {
      return next(ApiError.badRequest("Validation failed", err.flatten().fieldErrors));
    }
    next(err);
  }
};

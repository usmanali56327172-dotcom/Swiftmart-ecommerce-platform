import { Router } from "express";
import * as ctrl from "../controllers/analytics.controller";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();
router.use(authenticate, authorize("ADMIN"));

router.get("/summary", ctrl.getDashboardSummary);
router.get("/revenue", ctrl.getRevenueSeries);
router.get("/top-products", ctrl.getTopProducts);
router.get("/orders-by-status", ctrl.getOrdersByStatus);

export default router;

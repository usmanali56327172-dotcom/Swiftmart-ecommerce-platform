import { Router } from "express";
import * as ctrl from "../controllers/brand.controller";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();

router.get("/", ctrl.listBrands);
router.post("/", authenticate, authorize("ADMIN"), ctrl.createBrand);
router.patch("/:id", authenticate, authorize("ADMIN"), ctrl.updateBrand);
router.delete("/:id", authenticate, authorize("ADMIN"), ctrl.deleteBrand);

export default router;

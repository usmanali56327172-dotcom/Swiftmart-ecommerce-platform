import { Router } from "express";
import * as ctrl from "../controllers/cart.controller";
import { authenticate } from "../middleware/auth";

const router = Router();
router.use(authenticate);

router.get("/", ctrl.getCart);
router.post("/items", ctrl.addToCart);
router.patch("/items/:productId", ctrl.updateCartItem);
router.delete("/items/:productId", ctrl.removeCartItem);
router.delete("/", ctrl.clearCart);

export default router;

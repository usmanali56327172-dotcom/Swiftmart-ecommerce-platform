import { Router } from "express";
import * as ctrl from "../controllers/category.controller";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();

router.get("/", ctrl.listCategories);
router.post("/", authenticate, authorize("ADMIN"), ctrl.createCategory);
router.patch("/:id", authenticate, authorize("ADMIN"), ctrl.updateCategory);
router.delete("/:id", authenticate, authorize("ADMIN"), ctrl.deleteCategory);

export default router;

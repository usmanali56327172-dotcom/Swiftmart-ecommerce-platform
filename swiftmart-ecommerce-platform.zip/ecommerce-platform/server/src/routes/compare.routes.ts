import { Router } from "express";
import * as ctrl from "../controllers/compare.controller";
import { authenticate } from "../middleware/auth";

const router = Router();
router.use(authenticate);

router.get("/", ctrl.getCompareList);
router.post("/items", ctrl.addToCompare);
router.delete("/items/:productId", ctrl.removeFromCompare);

export default router;

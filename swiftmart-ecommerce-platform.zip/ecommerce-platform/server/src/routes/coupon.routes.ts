import { Router } from "express";
import * as ctrl from "../controllers/coupon.controller";
import { authenticate, authorize } from "../middleware/auth";
import { validate } from "../middleware/validate";
import { createCouponSchema, applyCouponSchema } from "../validators/coupon.validator";

const router = Router();

router.post("/apply", authenticate, validate(applyCouponSchema), ctrl.applyCoupon);
router.post("/remove", authenticate, ctrl.removeCoupon);
router.get("/", authenticate, authorize("ADMIN"), ctrl.listCoupons);
router.post("/", authenticate, authorize("ADMIN"), validate(createCouponSchema), ctrl.createCoupon);
router.patch("/:id/deactivate", authenticate, authorize("ADMIN"), ctrl.deactivateCoupon);

export default router;

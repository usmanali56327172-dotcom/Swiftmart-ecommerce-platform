import { Router } from "express";
import authRoutes from "./auth.routes";
import productRoutes from "./product.routes";
import categoryRoutes from "./category.routes";
import brandRoutes from "./brand.routes";
import cartRoutes from "./cart.routes";
import wishlistRoutes from "./wishlist.routes";
import compareRoutes from "./compare.routes";
import reviewRoutes from "./review.routes";
import couponRoutes from "./coupon.routes";
import addressRoutes from "./address.routes";
import orderRoutes from "./order.routes";
import paymentRoutes from "./payment.routes";
import analyticsRoutes from "./analytics.routes";
import uploadRoutes from "./upload.routes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/products", productRoutes);
router.use("/categories", categoryRoutes);
router.use("/brands", brandRoutes);
router.use("/cart", cartRoutes);
router.use("/wishlist", wishlistRoutes);
router.use("/compare", compareRoutes);
router.use("/reviews", reviewRoutes);
router.use("/coupons", couponRoutes);
router.use("/addresses", addressRoutes);
router.use("/orders", orderRoutes);
router.use("/payments", paymentRoutes);
router.use("/analytics", analyticsRoutes);
router.use("/uploads", uploadRoutes);

export default router;

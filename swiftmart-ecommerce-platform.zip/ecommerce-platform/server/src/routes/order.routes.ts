import { Router } from "express";
import * as ctrl from "../controllers/order.controller";
import { authenticate, authorize } from "../middleware/auth";
import { validate } from "../middleware/validate";
import { createOrderSchema, updateOrderStatusSchema, submitBankTransferSchema } from "../validators/order.validator";

const router = Router();
router.use(authenticate);

router.post("/", validate(createOrderSchema), ctrl.createOrder);
router.get("/my", ctrl.listMyOrders);
router.get("/admin/all", authorize("ADMIN"), ctrl.listAllOrders);
router.get("/:id", ctrl.getOrder);
router.patch("/:id/status", authorize("ADMIN"), validate(updateOrderStatusSchema), ctrl.updateOrderStatus);
router.post("/:id/bank-transfer/reference", validate(submitBankTransferSchema), ctrl.submitBankTransferReference);
router.patch("/:id/bank-transfer/verify", authorize("ADMIN"), ctrl.verifyBankTransfer);

export default router;

import { Router } from "express";
import * as ctrl from "../controllers/payment.controller";
import { authenticate } from "../middleware/auth";
import { BankTransferService } from "../services/bank-transfer.service";
import { asyncHandler } from "../utils/asyncHandler";
import { sendSuccess } from "../utils/ApiResponse";

const router = Router();

// NOTE: stripeWebhook and jazzCashCallback are mounted separately in app.ts
// with their respective body parsers (raw for Stripe, urlencoded for JazzCash).
router.get("/:intentId/status", authenticate, ctrl.getPaymentStatus);
router.get("/bank-details", authenticate, asyncHandler(async (_req, res) => {
  sendSuccess(res, BankTransferService.getBankDetails());
}));

export default router;

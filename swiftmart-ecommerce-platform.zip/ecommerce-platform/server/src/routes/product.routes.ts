import { Router } from "express";
import * as ctrl from "../controllers/product.controller";
import { validate } from "../middleware/validate";
import { authenticate, authorize } from "../middleware/auth";
import { createProductSchema, updateProductSchema, listProductsSchema } from "../validators/product.validator";

const router = Router();

router.get("/", validate(listProductsSchema), ctrl.listProducts);
router.get("/:slug", ctrl.getProduct);
router.post("/", authenticate, authorize("ADMIN"), validate(createProductSchema), ctrl.createProduct);
router.patch("/:id", authenticate, authorize("ADMIN"), validate(updateProductSchema), ctrl.updateProduct);
router.delete("/:id", authenticate, authorize("ADMIN"), ctrl.deleteProduct);

export default router;

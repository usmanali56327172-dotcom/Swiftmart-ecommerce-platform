import { Router } from "express";
import * as ctrl from "../controllers/review.controller";
import { authenticate } from "../middleware/auth";
import { validate } from "../middleware/validate";
import { createReviewSchema } from "../validators/review.validator";

const router = Router();

router.get("/product/:productId", ctrl.listReviewsForProduct);
router.post("/product/:productId", authenticate, validate(createReviewSchema), ctrl.createReview);
router.patch("/:id", authenticate, ctrl.updateReview);
router.delete("/:id", authenticate, ctrl.deleteReview);
router.post("/:id/helpful", authenticate, ctrl.markReviewHelpful);

export default router;

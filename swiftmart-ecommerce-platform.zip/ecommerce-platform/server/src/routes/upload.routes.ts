import { Router } from "express";
import * as ctrl from "../controllers/upload.controller";
import { authenticate, authorize } from "../middleware/auth";
import { uploadImage } from "../utils/multer";

const router = Router();
router.use(authenticate, authorize("ADMIN"));

router.post("/image", uploadImage.single("file"), ctrl.uploadProductImage);
router.post("/images", uploadImage.array("files", 8), ctrl.uploadProductImages);

export default router;

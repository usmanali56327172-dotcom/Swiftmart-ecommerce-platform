import { Router } from "express";
import * as ctrl from "../controllers/wishlist.controller";
import { authenticate } from "../middleware/auth";

const router = Router();
router.use(authenticate);

router.get("/", ctrl.getWishlist);
router.post("/items", ctrl.addToWishlist);
router.delete("/items/:productId", ctrl.removeFromWishlist);

export default router;

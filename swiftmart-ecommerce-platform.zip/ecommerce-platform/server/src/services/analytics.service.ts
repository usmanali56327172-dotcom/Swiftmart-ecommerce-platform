import { prisma } from "../config/prisma";
import { subDays, startOfDay } from "../utils/date";

export class AnalyticsService {
  static async dashboardSummary() {
    const [totalRevenue, totalOrders, totalCustomers, totalProducts, lowStockProducts, pendingOrders] =
      await Promise.all([
        prisma.order.aggregate({ _sum: { total: true }, where: { paymentStatus: "SUCCEEDED" } }),
        prisma.order.count(),
        prisma.user.count({ where: { role: "CUSTOMER" } }),
        prisma.product.count({ where: { isActive: true } }),
        prisma.product.findMany({
          where: { isActive: true },
          select: { id: true, title: true, stock: true, lowStockThreshold: true, thumbnail: true },
        }).then((rows) => rows.filter((p) => p.stock <= p.lowStockThreshold)),
        prisma.order.count({ where: { status: "PENDING" } }),
      ]);

    return {
      totalRevenue: totalRevenue._sum.total ?? 0,
      totalOrders,
      totalCustomers,
      totalProducts,
      pendingOrders,
      lowStockCount: lowStockProducts.length,
      lowStockProducts: lowStockProducts.slice(0, 10),
    };
  }

  /** Daily revenue + order-count series for the last N days, for charting. */
  static async revenueSeries(days = 30) {
    const since = startOfDay(subDays(new Date(), days));
    const orders = await prisma.order.findMany({
      where: { createdAt: { gte: since }, paymentStatus: "SUCCEEDED" },
      select: { createdAt: true, total: true },
    });

    const buckets = new Map<string, { revenue: number; orders: number }>();
    for (let i = 0; i < days; i++) {
      const day = startOfDay(subDays(new Date(), days - 1 - i)).toISOString().slice(0, 10);
      buckets.set(day, { revenue: 0, orders: 0 });
    }
    for (const order of orders) {
      const key = startOfDay(order.createdAt).toISOString().slice(0, 10);
      const bucket = buckets.get(key);
      if (bucket) {
        bucket.revenue += Number(order.total);
        bucket.orders += 1;
      }
    }
    return Array.from(buckets.entries()).map(([date, v]) => ({ date, ...v }));
  }

  static async topProducts(limit = 10) {
    return prisma.product.findMany({
      where: { isActive: true },
      orderBy: { totalSold: "desc" },
      take: limit,
      select: { id: true, title: true, thumbnail: true, totalSold: true, price: true, avgRating: true },
    });
  }

  static async ordersByStatus() {
    const results = await prisma.order.groupBy({ by: ["status"], _count: { status: true } });
    return results.map((r) => ({ status: r.status, count: r._count.status }));
  }
}

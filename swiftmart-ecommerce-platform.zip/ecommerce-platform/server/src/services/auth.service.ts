import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import { comparePassword, hashPassword } from "../utils/password";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../utils/jwt";
import { env } from "../config/env";

const REFRESH_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

export class AuthService {
  static async register(name: string, email: string, password: string) {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) throw ApiError.conflict("An account with this email already exists");

    const passwordHash = await hashPassword(password);
    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash,
        cart: { create: {} },
        wishlist: { create: {} },
      },
    });

    return AuthService.issueTokens(user.id, user.role);
  }

  static async login(email: string, password: string) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw ApiError.unauthorized("Invalid email or password");

    const valid = await comparePassword(password, user.passwordHash);
    if (!valid) throw ApiError.unauthorized("Invalid email or password");

    const tokens = await AuthService.issueTokens(user.id, user.role);
    return { ...tokens, user };
  }

  static async issueTokens(userId: string, role: "CUSTOMER" | "ADMIN") {
    const accessToken = signAccessToken({ sub: userId, role });
    const refreshToken = signRefreshToken(userId);

    await prisma.refreshToken.create({
      data: {
        token: refreshToken,
        userId,
        expiresAt: new Date(Date.now() + REFRESH_TOKEN_TTL_MS),
      },
    });

    return { accessToken, refreshToken };
  }

  /** Rotates a refresh token: verifies, revokes the old one, issues a new pair. */
  static async refresh(oldToken: string) {
    let payload;
    try {
      payload = verifyRefreshToken(oldToken);
    } catch {
      throw ApiError.unauthorized("Invalid refresh token");
    }

    const stored = await prisma.refreshToken.findUnique({ where: { token: oldToken } });
    if (!stored || stored.revoked || stored.expiresAt < new Date()) {
      throw ApiError.unauthorized("Refresh token expired or revoked");
    }

    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) throw ApiError.unauthorized("User no longer exists");

    await prisma.refreshToken.update({ where: { id: stored.id }, data: { revoked: true } });
    return AuthService.issueTokens(user.id, user.role);
  }

  static async logout(token: string) {
    await prisma.refreshToken.updateMany({ where: { token }, data: { revoked: true } });
  }

  static async me(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true, name: true, email: true, role: true, avatarUrl: true, phone: true, createdAt: true,
      },
    });
    if (!user) throw ApiError.notFound("User not found");
    return user;
  }

  static async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
    const valid = await comparePassword(currentPassword, user.passwordHash);
    if (!valid) throw ApiError.badRequest("Current password is incorrect");
    const passwordHash = await hashPassword(newPassword);
    await prisma.user.update({ where: { id: userId }, data: { passwordHash } });
  }
}

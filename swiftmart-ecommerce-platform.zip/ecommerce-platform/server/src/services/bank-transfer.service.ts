import { env } from "../config/env";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

export class BankTransferService {
  /** Account details shown to the customer at checkout so they can wire the funds. */
  static getBankDetails() {
    return {
      bankName: env.BANK_NAME,
      accountTitle: env.BANK_ACCOUNT_TITLE,
      accountNumber: env.BANK_ACCOUNT_NUMBER,
      iban: env.BANK_IBAN,
    };
  }

  /** Customer submits their transfer/slip reference after paying manually. */
  static async submitReference(userId: string, orderId: string, reference: string) {
    const order = await prisma.order.findFirst({ where: { id: orderId, userId } });
    if (!order) throw ApiError.notFound("Order not found");
    if (order.paymentMethod !== "BANK_TRANSFER") throw ApiError.badRequest("This order is not a bank transfer order");

    return prisma.order.update({
      where: { id: orderId },
      data: {
        bankTransferReference: reference,
        trackingEvents: { create: { status: order.status, message: `Customer submitted bank transfer reference: ${reference}` } },
      },
    });
  }

  /** Admin confirms the funds actually landed and releases the order for fulfillment. */
  static async verifyByAdmin(adminId: string, orderId: string) {
    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) throw ApiError.notFound("Order not found");
    if (order.paymentMethod !== "BANK_TRANSFER") throw ApiError.badRequest("This order is not a bank transfer order");
    if (order.paymentStatus === "SUCCEEDED") throw ApiError.conflict("Order already verified");

    return prisma.order.update({
      where: { id: orderId },
      data: {
        paymentStatus: "SUCCEEDED",
        status: "PAID",
        bankTransferVerifiedAt: new Date(),
        bankTransferVerifiedBy: adminId,
        trackingEvents: { create: { status: "PAID", message: "Bank transfer verified by our team — payment confirmed" } },
      },
    });
  }
}

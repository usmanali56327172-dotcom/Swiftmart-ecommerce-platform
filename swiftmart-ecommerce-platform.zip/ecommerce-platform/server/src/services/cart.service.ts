import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

export class CartService {
  static async getOrCreate(userId: string) {
    let cart = await prisma.cart.findUnique({
      where: { userId },
      include: { items: { include: { product: true } }, coupon: true },
    });
    if (!cart) {
      cart = await prisma.cart.create({
        data: { userId },
        include: { items: { include: { product: true } }, coupon: true },
      });
    }
    return cart;
  }

  static async addItem(userId: string, productId: string, quantity: number) {
    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product || !product.isActive) throw ApiError.notFound("Product not found");
    if (product.stock < quantity) throw ApiError.badRequest("Not enough stock available");

    const cart = await CartService.getOrCreate(userId);
    await prisma.cartItem.upsert({
      where: { cartId_productId: { cartId: cart.id, productId } },
      create: { cartId: cart.id, productId, quantity },
      update: { quantity: { increment: quantity } },
    });
    return CartService.getOrCreate(userId);
  }

  static async updateItem(userId: string, productId: string, quantity: number) {
    const cart = await CartService.getOrCreate(userId);
    if (quantity <= 0) {
      await prisma.cartItem.deleteMany({ where: { cartId: cart.id, productId } });
    } else {
      const product = await prisma.product.findUniqueOrThrow({ where: { id: productId } });
      if (product.stock < quantity) throw ApiError.badRequest("Not enough stock available");
      await prisma.cartItem.updateMany({ where: { cartId: cart.id, productId }, data: { quantity } });
    }
    return CartService.getOrCreate(userId);
  }

  static async removeItem(userId: string, productId: string) {
    const cart = await CartService.getOrCreate(userId);
    await prisma.cartItem.deleteMany({ where: { cartId: cart.id, productId } });
    return CartService.getOrCreate(userId);
  }

  static async clear(userId: string) {
    const cart = await CartService.getOrCreate(userId);
    await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
    await prisma.cart.update({ where: { id: cart.id }, data: { couponId: null } });
  }

  /** Computes cart totals server-side — never trust client-submitted prices. */
  static calculateTotals(cart: Awaited<ReturnType<typeof CartService.getOrCreate>>) {
    const subtotal = cart.items.reduce(
      (sum, item) => sum + Number(item.product.price) * item.quantity,
      0
    );

    let discount = 0;
    if (cart.coupon && cart.coupon.isActive) {
      const c = cart.coupon;
      const meetsMin = !c.minOrderAmount || subtotal >= Number(c.minOrderAmount);
      if (meetsMin) {
        discount =
          c.type === "PERCENTAGE" ? (subtotal * Number(c.value)) / 100 : Number(c.value);
        if (c.maxDiscount) discount = Math.min(discount, Number(c.maxDiscount));
      }
    }

    const shippingFee = subtotal > 0 && subtotal < 5000 ? 250 : 0;
    const tax = Math.round((subtotal - discount) * 0.08 * 100) / 100;
    const total = Math.max(subtotal - discount + shippingFee + tax, 0);

    return { subtotal, discount, shippingFee, tax, total };
  }
}

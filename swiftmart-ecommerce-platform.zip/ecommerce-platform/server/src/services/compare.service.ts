import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

const MAX_COMPARE_ITEMS = 4;

export class CompareService {
  static async list(userId: string) {
    return prisma.compareItem.findMany({ where: { userId }, include: { product: { include: { category: true, brand: true } } } });
  }

  static async add(userId: string, productId: string) {
    const count = await prisma.compareItem.count({ where: { userId } });
    if (count >= MAX_COMPARE_ITEMS) {
      throw ApiError.badRequest(`You can compare up to ${MAX_COMPARE_ITEMS} products at a time`);
    }
    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product) throw ApiError.notFound("Product not found");

    await prisma.compareItem.upsert({
      where: { userId_productId: { userId, productId } },
      create: { userId, productId },
      update: {},
    });
    return CompareService.list(userId);
  }

  static async remove(userId: string, productId: string) {
    await prisma.compareItem.deleteMany({ where: { userId, productId } });
    return CompareService.list(userId);
  }
}

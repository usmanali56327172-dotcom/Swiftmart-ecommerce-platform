import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import { CartService } from "./cart.service";

export class CouponService {
  static async apply(userId: string, code: string) {
    const coupon = await prisma.coupon.findUnique({ where: { code: code.toUpperCase() } });
    if (!coupon || !coupon.isActive) throw ApiError.notFound("Coupon not found or inactive");

    const now = new Date();
    if (coupon.startsAt && coupon.startsAt > now) throw ApiError.badRequest("Coupon is not active yet");
    if (coupon.expiresAt && coupon.expiresAt < now) throw ApiError.badRequest("Coupon has expired");
    if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
      throw ApiError.badRequest("Coupon usage limit reached");
    }

    const cart = await CartService.getOrCreate(userId);
    if (cart.items.length === 0) throw ApiError.badRequest("Your cart is empty");

    const { subtotal } = CartService.calculateTotals(cart);
    if (coupon.minOrderAmount && subtotal < Number(coupon.minOrderAmount)) {
      throw ApiError.badRequest(`Minimum order amount for this coupon is $${coupon.minOrderAmount}`);
    }

    await prisma.cart.update({ where: { id: cart.id }, data: { couponId: coupon.id } });
    return CartService.getOrCreate(userId);
  }

  static async remove(userId: string) {
    const cart = await CartService.getOrCreate(userId);
    await prisma.cart.update({ where: { id: cart.id }, data: { couponId: null } });
    return CartService.getOrCreate(userId);
  }

  static async listAll() {
    return prisma.coupon.findMany({ orderBy: { createdAt: "desc" } });
  }

  static async create(data: Parameters<typeof prisma.coupon.create>[0]["data"]) {
    return prisma.coupon.create({ data });
  }

  static async deactivate(id: string) {
    return prisma.coupon.update({ where: { id }, data: { isActive: false } });
  }
}

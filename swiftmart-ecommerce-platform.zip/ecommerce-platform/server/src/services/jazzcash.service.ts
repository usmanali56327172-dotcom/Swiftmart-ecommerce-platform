import crypto from "crypto";
import { env } from "../config/env";

/**
 * JazzCash Mobile Account (MWALLET) integration.
 *
 * JazzCash's API expects a form-encoded request signed with a "Secure Hash":
 * every pp_* field is sorted alphabetically by key, concatenated with '&',
 * prefixed with the integrity salt, then HMAC-SHA256'd. The same algorithm
 * is used to verify the signature JazzCash sends back on the callback, which
 * is how we confirm a transaction actually succeeded (never trust the
 * client-side redirect alone).
 *
 * Docs: https://sandbox.jazzcash.com.pk/Sandbox/Home/Index (merchant portal)
 */

interface JazzCashRequestParams {
  amount: number; // in PKR
  orderId: string;
  orderNumber: string;
  mobileAccountNumber: string; // customer's JazzCash-registered mobile number
  cnic: string; // last 6 digits of CNIC, required by JazzCash MWALLET API
}

export class JazzCashService {
  /** Builds the signed payload to POST to JazzCash's DoMWalletTransaction endpoint. */
  static buildTransactionRequest(params: JazzCashRequestParams) {
    const now = new Date();
    const txnDateTime = JazzCashService.formatDateTime(now);
    const txnExpiryDateTime = JazzCashService.formatDateTime(new Date(now.getTime() + 60 * 60 * 1000));
    const txnRefNo = `T${now.getTime()}`;

    const fields: Record<string, string> = {
      pp_Version: "1.1",
      pp_TxnType: "MWALLET",
      pp_Language: "EN",
      pp_MerchantID: env.JAZZCASH_MERCHANT_ID,
      pp_Password: env.JAZZCASH_PASSWORD,
      pp_TxnRefNo: txnRefNo,
      pp_Amount: String(Math.round(params.amount * 100)), // JazzCash expects amount in paisa
      pp_TxnCurrency: "PKR",
      pp_TxnDateTime: txnDateTime,
      pp_BillReference: params.orderNumber,
      pp_Description: `Order ${params.orderNumber}`,
      pp_TxnExpiryDateTime: txnExpiryDateTime,
      pp_ReturnURL: env.JAZZCASH_RETURN_URL,
      pp_SecureHash: "", // filled below
      pp_MobileNumber: params.mobileAccountNumber,
      pp_CNIC: params.cnic,
    };

    fields.pp_SecureHash = JazzCashService.computeSecureHash(fields);

    return { fields, txnRefNo, apiUrl: env.JAZZCASH_API_BASE };
  }

  /** Verifies the signature on an inbound JazzCash callback before trusting it. */
  static verifyCallback(payload: Record<string, string>): boolean {
    const { pp_SecureHash, ...rest } = payload;
    if (!pp_SecureHash) return false;
    const expected = JazzCashService.computeSecureHash(rest);
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(pp_SecureHash));
  }

  static isSuccessResponseCode(code: string | undefined) {
    return code === "000"; // JazzCash: "000" = success
  }

  private static computeSecureHash(fields: Record<string, string>) {
    const sortedKeys = Object.keys(fields)
      .filter((k) => k !== "pp_SecureHash" && fields[k] !== undefined && fields[k] !== "")
      .sort();
    const concatenated = sortedKeys.map((k) => fields[k]).join("&");
    const signedString = `${env.JAZZCASH_INTEGRITY_SALT}&${concatenated}`;
    return crypto.createHmac("sha256", env.JAZZCASH_INTEGRITY_SALT).update(signedString).digest("hex");
  }

  private static formatDateTime(date: Date) {
    // JazzCash expects yyyyMMddHHmmss
    const pad = (n: number) => String(n).padStart(2, "0");
    return (
      date.getFullYear().toString() +
      pad(date.getMonth() + 1) +
      pad(date.getDate()) +
      pad(date.getHours()) +
      pad(date.getMinutes()) +
      pad(date.getSeconds())
    );
  }
}

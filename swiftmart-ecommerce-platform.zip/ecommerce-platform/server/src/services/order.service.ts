import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import { CartService } from "./cart.service";
import { PaymentService } from "./payment.service";
import { JazzCashService } from "./jazzcash.service";
import { BankTransferService } from "./bank-transfer.service";
import { generateOrderNumber } from "../utils/orderNumber";
import { OrderStatus, PaymentMethod } from "@prisma/client";

export type CheckoutPaymentMethod = "card" | "jazzcash" | "bank_transfer" | "cod";

const PAYMENT_METHOD_MAP: Record<CheckoutPaymentMethod, PaymentMethod> = {
  card: "CARD",
  jazzcash: "JAZZCASH",
  bank_transfer: "BANK_TRANSFER",
  cod: "COD",
};

export class OrderService {
  /**
   * Creates an order from the user's current cart in a single transaction:
   * validates stock, snapshots prices, decrements inventory, clears the cart,
   * then kicks off the appropriate payment flow:
   *  - card          → Stripe PaymentIntent (confirmed client-side, verified via webhook)
   *  - jazzcash      → signed JazzCash MWALLET request (customer approves on their phone)
   *  - bank_transfer → order held as AWAITING_VERIFICATION until an admin confirms funds
   *  - cod           → no payment collected upfront
   */
  static async createFromCart(
    userId: string,
    addressId: string,
    paymentMethod: CheckoutPaymentMethod,
    jazzCashDetails?: { mobileNumber: string; cnic: string }
  ) {
    const cart = await CartService.getOrCreate(userId);
    if (cart.items.length === 0) throw ApiError.badRequest("Your cart is empty");

    const address = await prisma.address.findFirst({ where: { id: addressId, userId } });
    if (!address) throw ApiError.notFound("Shipping address not found");

    if (paymentMethod === "jazzcash" && !jazzCashDetails) {
      throw ApiError.badRequest("JazzCash mobile number and CNIC digits are required");
    }

    for (const item of cart.items) {
      if (item.product.stock < item.quantity) {
        throw ApiError.badRequest(`"${item.product.title}" no longer has enough stock`);
      }
    }

    const { subtotal, discount, shippingFee, tax, total } = CartService.calculateTotals(cart);

    const initialPaymentStatus = paymentMethod === "bank_transfer" ? "AWAITING_VERIFICATION" : "PENDING";

    const order = await prisma.$transaction(async (tx) => {
      const created = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          userId,
          addressId,
          subtotal,
          discount,
          shippingFee,
          tax,
          total,
          couponId: cart.couponId,
          paymentMethod: PAYMENT_METHOD_MAP[paymentMethod],
          paymentStatus: initialPaymentStatus,
          status: "PENDING",
          items: {
            create: cart.items.map((item) => ({
              productId: item.productId,
              title: item.product.title,
              thumbnail: item.product.thumbnail,
              price: item.product.price,
              quantity: item.quantity,
            })),
          },
          trackingEvents: {
            create: { status: "PENDING", message: "Order placed successfully" },
          },
        },
        include: { items: true, trackingEvents: true, address: true },
      });

      for (const item of cart.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity }, totalSold: { increment: item.quantity } },
        });
        await tx.inventoryLog.create({
          data: { productId: item.productId, change: -item.quantity, reason: "SALE", note: `Order ${created.orderNumber}` },
        });
      }

      if (cart.couponId) {
        await tx.coupon.update({ where: { id: cart.couponId }, data: { usedCount: { increment: 1 } } });
      }

      await tx.cartItem.deleteMany({ where: { cartId: cart.id } });
      await tx.cart.update({ where: { id: cart.id }, data: { couponId: null } });

      return created;
    });

    if (paymentMethod === "card") {
      const intent = await PaymentService.createPaymentIntent(total, "pkr", { orderId: order.id, orderNumber: order.orderNumber });
      await prisma.order.update({ where: { id: order.id }, data: { paymentIntentId: intent.id } });
      return { order, clientSecret: intent.client_secret, jazzCash: null, bankTransfer: null };
    }

    if (paymentMethod === "jazzcash" && jazzCashDetails) {
      const { fields, txnRefNo, apiUrl } = JazzCashService.buildTransactionRequest({
        amount: total,
        orderId: order.id,
        orderNumber: order.orderNumber,
        mobileAccountNumber: jazzCashDetails.mobileNumber,
        cnic: jazzCashDetails.cnic,
      });
      await prisma.order.update({ where: { id: order.id }, data: { jazzCashTxnRef: txnRefNo } });
      return { order, clientSecret: null, jazzCash: { apiUrl, fields }, bankTransfer: null };
    }

    if (paymentMethod === "bank_transfer") {
      return { order, clientSecret: null, jazzCash: null, bankTransfer: BankTransferService.getBankDetails() };
    }

    return { order, clientSecret: null, jazzCash: null, bankTransfer: null };
  }

  static async markPaid(orderId: string) {
    await prisma.order.update({
      where: { id: orderId },
      data: {
        paymentStatus: "SUCCEEDED",
        status: "PAID",
        trackingEvents: { create: { status: "PAID", message: "Payment confirmed" } },
      },
    });
  }

  static async markJazzCashResult(txnRefNo: string, responseCode: string, responseMessage: string) {
    const order = await prisma.order.findFirst({ where: { jazzCashTxnRef: txnRefNo } });
    if (!order) throw ApiError.notFound("Order not found for this JazzCash transaction");

    const succeeded = JazzCashService.isSuccessResponseCode(responseCode);
    await prisma.order.update({
      where: { id: order.id },
      data: {
        jazzCashTxnStatus: responseCode,
        paymentStatus: succeeded ? "SUCCEEDED" : "FAILED",
        status: succeeded ? "PAID" : order.status,
        trackingEvents: {
          create: {
            status: succeeded ? "PAID" : order.status,
            message: succeeded ? "JazzCash payment confirmed" : `JazzCash payment failed: ${responseMessage}`,
          },
        },
      },
    });
    return order.id;
  }

  static async listForUser(userId: string, page: number, limit: number) {
    const [items, total] = await Promise.all([
      prisma.order.findMany({
        where: { userId },
        include: { items: true, trackingEvents: { orderBy: { createdAt: "desc" } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.order.count({ where: { userId } }),
    ]);
    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  static async getById(userId: string, role: string, orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true, address: true, trackingEvents: { orderBy: { createdAt: "asc" } }, user: { select: { id: true, name: true, email: true } } },
    });
    if (!order) throw ApiError.notFound("Order not found");
    if (order.userId !== userId && role !== "ADMIN") throw ApiError.forbidden();
    return order;
  }

  static async updateStatus(orderId: string, status: OrderStatus, message: string, location?: string) {
    return prisma.order.update({
      where: { id: orderId },
      data: { status, trackingEvents: { create: { status, message, location } } },
      include: { trackingEvents: true },
    });
  }

  static async listAllForAdmin(page: number, limit: number, status?: OrderStatus) {
    const where = status ? { status } : {};
    const [items, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: { items: true, user: { select: { id: true, name: true, email: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.order.count({ where }),
    ]);
    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }
}

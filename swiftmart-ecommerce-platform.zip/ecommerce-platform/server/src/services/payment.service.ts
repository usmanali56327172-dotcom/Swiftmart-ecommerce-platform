import Stripe from "stripe";
import { env } from "../config/env";

export const stripe = new Stripe(env.STRIPE_SECRET_KEY || "sk_test_placeholder", {
  apiVersion: "2024-06-20",
});

export class PaymentService {
  /** Creates a PaymentIntent for the given order total (in the currency's smallest unit). */
  static async createPaymentIntent(amount: number, currency = "pkr", metadata: Record<string, string> = {}) {
    return stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency,
      metadata,
      automatic_payment_methods: { enabled: true },
    });
  }

  static async retrievePaymentIntent(id: string) {
    return stripe.paymentIntents.retrieve(id);
  }

  static constructWebhookEvent(payload: Buffer, signature: string) {
    return stripe.webhooks.constructEvent(payload, signature, env.STRIPE_WEBHOOK_SECRET);
  }
}

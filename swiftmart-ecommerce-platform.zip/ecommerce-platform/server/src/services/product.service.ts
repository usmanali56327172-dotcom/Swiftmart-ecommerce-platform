import { Prisma } from "@prisma/client";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

interface ListParams {
  page: number;
  limit: number;
  search?: string;
  category?: string;
  brand?: string;
  minPrice?: number;
  maxPrice?: number;
  rating?: number;
  sort?: "newest" | "price_asc" | "price_desc" | "rating" | "popular";
  inStock?: boolean;
}

export class ProductService {
  /** Full-text-ish search + multi-facet filtering + pagination, tuned for catalog browsing. */
  static async list(params: ListParams) {
    const { page, limit, search, category, brand, minPrice, maxPrice, rating, sort, inStock } = params;

    const where: Prisma.ProductWhereInput = {
      isActive: true,
      ...(search
        ? {
            OR: [
              { title: { contains: search, mode: "insensitive" } },
              { description: { contains: search, mode: "insensitive" } },
              { tags: { has: search.toLowerCase() } },
            ],
          }
        : {}),
      ...(category ? { category: { slug: category } } : {}),
      ...(brand ? { brand: { slug: brand } } : {}),
      ...(minPrice || maxPrice
        ? { price: { ...(minPrice ? { gte: minPrice } : {}), ...(maxPrice ? { lte: maxPrice } : {}) } }
        : {}),
      ...(rating ? { avgRating: { gte: rating } } : {}),
      ...(inStock ? { stock: { gt: 0 } } : {}),
    };

    const orderBy: Prisma.ProductOrderByWithRelationInput =
      sort === "price_asc" ? { price: "asc" } :
      sort === "price_desc" ? { price: "desc" } :
      sort === "rating" ? { avgRating: "desc" } :
      sort === "popular" ? { totalSold: "desc" } :
      { createdAt: "desc" };

    const [items, total] = await Promise.all([
      prisma.product.findMany({
        where,
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
        include: { category: true, brand: true },
      }),
      prisma.product.count({ where }),
    ]);

    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  static async getBySlug(slug: string) {
    const product = await prisma.product.findUnique({
      where: { slug },
      include: {
        category: true,
        brand: true,
        reviews: { include: { user: { select: { id: true, name: true, avatarUrl: true } } }, orderBy: { createdAt: "desc" } },
      },
    });
    if (!product || !product.isActive) throw ApiError.notFound("Product not found");
    return product;
  }

  static async getRelated(productId: string, categoryId: string, limit = 8) {
    return prisma.product.findMany({
      where: { categoryId, id: { not: productId }, isActive: true },
      take: limit,
      orderBy: { avgRating: "desc" },
    });
  }

  static async create(data: Prisma.ProductUncheckedCreateInput) {
    const slug = ProductService.slugify(data.title as string);
    const product = await prisma.product.create({ data: { ...data, slug } });
    await prisma.inventoryLog.create({
      data: { productId: product.id, change: product.stock, reason: "RESTOCK", note: "Initial stock" },
    });
    return product;
  }

  static async update(id: string, data: Prisma.ProductUncheckedUpdateInput) {
    const existing = await prisma.product.findUnique({ where: { id } });
    if (!existing) throw ApiError.notFound("Product not found");

    if (data.stock !== undefined && typeof data.stock === "number") {
      const diff = data.stock - existing.stock;
      if (diff !== 0) {
        await prisma.inventoryLog.create({
          data: { productId: id, change: diff, reason: "ADJUSTMENT", note: "Manual stock update" },
        });
      }
    }

    return prisma.product.update({ where: { id }, data });
  }

  static async delete(id: string) {
    const existing = await prisma.product.findUnique({ where: { id } });
    if (!existing) throw ApiError.notFound("Product not found");
    // Soft delete keeps historical order/review integrity intact.
    return prisma.product.update({ where: { id }, data: { isActive: false } });
  }

  static async recalculateRating(productId: string) {
    const agg = await prisma.review.aggregate({
      where: { productId },
      _avg: { rating: true },
      _count: { rating: true },
    });
    await prisma.product.update({
      where: { id: productId },
      data: { avgRating: agg._avg.rating ?? 0, reviewCount: agg._count.rating },
    });
  }

  static slugify(title: string) {
    return (
      title
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "") + "-" + Math.random().toString(36).slice(2, 7)
    );
  }
}

import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";
import { ProductService } from "./product.service";

export class ReviewService {
  static async create(userId: string, productId: string, rating: number, comment: string, title?: string) {
    const existing = await prisma.review.findUnique({ where: { productId_userId: { productId, userId } } });
    if (existing) throw ApiError.conflict("You have already reviewed this product");

    // A verified purchase badge requires a delivered order containing this product.
    const purchase = await prisma.orderItem.findFirst({
      where: { productId, order: { userId, status: "DELIVERED" } },
    });

    const review = await prisma.review.create({
      data: { userId, productId, rating, comment, title, isVerifiedPurchase: !!purchase },
    });

    await ProductService.recalculateRating(productId);
    return review;
  }

  static async update(userId: string, reviewId: string, rating?: number, comment?: string, title?: string) {
    const review = await prisma.review.findUnique({ where: { id: reviewId } });
    if (!review) throw ApiError.notFound("Review not found");
    if (review.userId !== userId) throw ApiError.forbidden("You can only edit your own review");

    const updated = await prisma.review.update({
      where: { id: reviewId },
      data: { ...(rating !== undefined ? { rating } : {}), ...(comment ? { comment } : {}), ...(title ? { title } : {}) },
    });
    await ProductService.recalculateRating(review.productId);
    return updated;
  }

  static async delete(userId: string, role: string, reviewId: string) {
    const review = await prisma.review.findUnique({ where: { id: reviewId } });
    if (!review) throw ApiError.notFound("Review not found");
    if (review.userId !== userId && role !== "ADMIN") throw ApiError.forbidden();

    await prisma.review.delete({ where: { id: reviewId } });
    await ProductService.recalculateRating(review.productId);
  }

  static async markHelpful(reviewId: string) {
    return prisma.review.update({ where: { id: reviewId }, data: { helpfulCount: { increment: 1 } } });
  }
}

import { prisma } from "../config/prisma";
import { ApiError } from "../utils/ApiError";

export class WishlistService {
  static async getOrCreate(userId: string) {
    let wishlist = await prisma.wishlist.findUnique({
      where: { userId },
      include: { items: { include: { product: true } } },
    });
    if (!wishlist) {
      wishlist = await prisma.wishlist.create({
        data: { userId },
        include: { items: { include: { product: true } } },
      });
    }
    return wishlist;
  }

  static async add(userId: string, productId: string) {
    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product) throw ApiError.notFound("Product not found");

    const wishlist = await WishlistService.getOrCreate(userId);
    await prisma.wishlistItem.upsert({
      where: { wishlistId_productId: { wishlistId: wishlist.id, productId } },
      create: { wishlistId: wishlist.id, productId },
      update: {},
    });
    return WishlistService.getOrCreate(userId);
  }

  static async remove(userId: string, productId: string) {
    const wishlist = await WishlistService.getOrCreate(userId);
    await prisma.wishlistItem.deleteMany({ where: { wishlistId: wishlist.id, productId } });
    return WishlistService.getOrCreate(userId);
  }
}

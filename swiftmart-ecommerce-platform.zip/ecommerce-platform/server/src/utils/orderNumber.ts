import { customAlphabet } from "nanoid";

const nanoid = customAlphabet("0123456789", 8);

/** Generates a human-friendly, sortable order number, e.g. ORD-20260713-48213590 */
export const generateOrderNumber = () => {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  return `ORD-${date}-${nanoid()}`;
};

import { z } from "zod";

export const createCouponSchema = z.object({
  body: z.object({
    code: z.string().min(3).max(30).toUpperCase(),
    type: z.enum(["PERCENTAGE", "FIXED"]),
    value: z.number().positive(),
    minOrderAmount: z.number().positive().optional(),
    maxDiscount: z.number().positive().optional(),
    usageLimit: z.number().int().positive().optional(),
    startsAt: z.string().datetime().optional(),
    expiresAt: z.string().datetime().optional(),
  }),
});

export const applyCouponSchema = z.object({
  body: z.object({ code: z.string().min(3) }),
});

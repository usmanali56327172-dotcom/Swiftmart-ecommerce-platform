import { z } from "zod";

export const createOrderSchema = z.object({
  body: z.object({
    addressId: z.string().uuid(),
    paymentMethod: z.enum(["card", "jazzcash", "bank_transfer", "cod"]),
    // Required only when paymentMethod === "jazzcash"
    jazzCashMobileNumber: z.string().regex(/^03\d{9}$/, "Enter a valid JazzCash mobile number, e.g. 03001234567").optional(),
    jazzCashCnic: z.string().regex(/^\d{6}$/, "Enter the last 6 digits of your CNIC").optional(),
    couponCode: z.string().optional(),
  }),
});

export const submitBankTransferSchema = z.object({
  body: z.object({ reference: z.string().min(3, "Enter your transfer reference or slip number") }),
  params: z.object({ id: z.string().uuid() }),
});

export const updateOrderStatusSchema = z.object({
  body: z.object({
    status: z.enum([
      "PENDING", "PAID", "PROCESSING", "SHIPPED", "OUT_FOR_DELIVERY", "DELIVERED", "CANCELLED", "REFUNDED",
    ]),
    message: z.string().min(1),
    location: z.string().optional(),
  }),
  params: z.object({ id: z.string().uuid() }),
});

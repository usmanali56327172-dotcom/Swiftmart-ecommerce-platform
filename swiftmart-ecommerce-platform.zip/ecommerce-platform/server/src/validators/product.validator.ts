import { z } from "zod";

export const createProductSchema = z.object({
  body: z.object({
    title: z.string().min(3).max(200),
    description: z.string().min(10),
    price: z.number().positive(),
    compareAtPrice: z.number().positive().optional(),
    costPrice: z.number().positive().optional(),
    sku: z.string().min(3),
    stock: z.number().int().nonnegative(),
    images: z.array(z.string().url()).min(1),
    thumbnail: z.string().url(),
    categoryId: z.string().uuid(),
    brandId: z.string().uuid().optional(),
    attributes: z.record(z.any()).optional(),
    tags: z.array(z.string()).optional(),
    isFeatured: z.boolean().optional(),
    weight: z.number().positive().optional(),
  }),
});

export const updateProductSchema = z.object({
  body: createProductSchema.shape.body.partial(),
  params: z.object({ id: z.string().uuid() }),
});

export const listProductsSchema = z.object({
  query: z.object({
    page: z.string().optional(),
    limit: z.string().optional(),
    search: z.string().optional(),
    category: z.string().optional(),
    brand: z.string().optional(),
    minPrice: z.string().optional(),
    maxPrice: z.string().optional(),
    rating: z.string().optional(),
    sort: z.enum(["newest", "price_asc", "price_desc", "rating", "popular"]).optional(),
    inStock: z.string().optional(),
  }),
});

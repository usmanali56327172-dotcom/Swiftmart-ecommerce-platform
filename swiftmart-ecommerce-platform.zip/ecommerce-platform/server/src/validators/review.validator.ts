import { z } from "zod";

export const createReviewSchema = z.object({
  body: z.object({
    rating: z.number().int().min(1).max(5),
    title: z.string().max(150).optional(),
    comment: z.string().min(5).max(2000),
  }),
  params: z.object({ productId: z.string().uuid() }),
});
